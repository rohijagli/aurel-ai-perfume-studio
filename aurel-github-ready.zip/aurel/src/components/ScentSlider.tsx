"use client";

import { useId } from "react";

interface ScentSliderProps {
  label: string;
  value: number;
  onChange: (value: number) => void;
  color: string;
  low: string;
  high: string;
}

export function ScentSlider({ label, value, onChange, color, low, high }: ScentSliderProps) {
  const id = useId();
  return (
    <div>
      <div className="flex items-center justify-between">
        <label htmlFor={id} className="flex items-center gap-2.5 text-sm font-medium text-ink">
          <span className="h-2 w-2 rounded-full" style={{ backgroundColor: color }} />
          {label}
        </label>
        <span className="font-serif text-xl tabular-nums text-ink">{value}</span>
      </div>
      <input
        id={id}
        type="range"
        min={0}
        max={100}
        step={1}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="aurel-range mt-2"
        style={{ "--val": `${value}%`, "--track-color": color } as React.CSSProperties}
        aria-valuetext={`${label} ${value} of 100`}
      />
      <div className="mt-0.5 flex justify-between text-[0.65rem] uppercase tracking-[0.16em] text-stone/80">
        <span>{low}</span>
        <span>{high}</span>
      </div>
    </div>
  );
}
