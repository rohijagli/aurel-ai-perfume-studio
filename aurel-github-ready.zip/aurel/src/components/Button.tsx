"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

type Variant = "primary" | "secondary" | "ghost" | "gold" | "outlineLight";
type Size = "sm" | "md" | "lg";

const VARIANTS: Record<Variant, string> = {
  primary:
    "bg-ink text-ivory hover:bg-charcoal shadow-[0_10px_30px_-12px_rgba(27,24,21,0.55)] disabled:bg-stone/50 disabled:shadow-none",
  secondary:
    "bg-white/60 text-ink border border-ink/15 hover:border-ink/40 hover:bg-white backdrop-blur disabled:opacity-50",
  ghost: "text-ink hover:bg-ink/5 disabled:opacity-50",
  outlineLight: "border border-ivory/25 text-ivory hover:border-ivory/60 hover:bg-ivory/5 disabled:opacity-50",
  gold: "bg-champagne text-ink hover:bg-[#d4b67e] shadow-[0_10px_30px_-14px_rgba(168,135,78,0.8)] disabled:opacity-50",
};

const SIZES: Record<Size, string> = {
  sm: "h-9 px-4 text-[0.78rem]",
  md: "h-11 px-6 text-[0.82rem]",
  lg: "h-13 px-8 text-[0.85rem] py-4",
};

interface CommonProps {
  variant?: Variant;
  size?: Size;
  className?: string;
  children: React.ReactNode;
  icon?: React.ReactNode;
  iconLeft?: React.ReactNode;
}

type ButtonProps = CommonProps & {
  href?: undefined;
  type?: "button" | "submit";
  onClick?: () => void;
  disabled?: boolean;
  ariaLabel?: string;
};

type LinkProps = CommonProps & { href: string; onClick?: () => void };

const base =
  "group relative inline-flex items-center justify-center gap-2.5 rounded-full font-semibold uppercase tracking-[0.16em] transition-colors duration-300 select-none whitespace-nowrap disabled:cursor-not-allowed";

function Inner({ children, icon, iconLeft }: Pick<CommonProps, "children" | "icon" | "iconLeft">) {
  return (
    <>
      {iconLeft}
      <span>{children}</span>
      {icon && (
        <span className="transition-transform duration-500 ease-[cubic-bezier(0.22,1,0.36,1)] group-hover:translate-x-1">
          {icon}
        </span>
      )}
    </>
  );
}

export function Button(props: ButtonProps | LinkProps) {
  const { variant = "primary", size = "md", className, children, icon, iconLeft } = props;
  const classes = cn(base, VARIANTS[variant], SIZES[size], className);

  if (props.href !== undefined) {
    return (
      <motion.span whileHover={{ y: -1 }} whileTap={{ scale: 0.98 }} className="inline-flex">
        <Link href={props.href} onClick={props.onClick} className={classes}>
          <Inner icon={icon} iconLeft={iconLeft}>
            {children}
          </Inner>
        </Link>
      </motion.span>
    );
  }

  const { type = "button", onClick, disabled, ariaLabel } = props;
  return (
    <motion.button
      type={type}
      onClick={onClick}
      disabled={disabled}
      aria-label={ariaLabel}
      whileHover={disabled ? undefined : { y: -1 }}
      whileTap={disabled ? undefined : { scale: 0.98 }}
      className={classes}
    >
      <Inner icon={icon} iconLeft={iconLeft}>
        {children}
      </Inner>
    </motion.button>
  );
}
