"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Check, Droplet } from "lucide-react";
import { cn } from "@/lib/utils";

/**
 * Drives a step-by-step "thinking" sequence alongside an async task.
 * The task result is only revealed once the final step has been shown,
 * so the demo always feels deliberate (and never flashes).
 */
export function useStepSequence(stepCount: number, interval = 750) {
  const [step, setStep] = useState(0);
  const timers = useRef<ReturnType<typeof setTimeout>[]>([]);

  const clear = () => {
    timers.current.forEach(clearTimeout);
    timers.current = [];
  };

  useEffect(() => clear, []);

  const run = useCallback(
    async <T,>(task: () => Promise<T>): Promise<T> => {
      clear();
      setStep(0);
      for (let i = 1; i < stepCount; i++) {
        timers.current.push(setTimeout(() => setStep(i), i * interval));
      }
      const minDuration = new Promise<void>((r) => setTimeout(r, (stepCount - 1) * interval + 550));
      const [result] = await Promise.all([task(), minDuration]);
      return result;
    },
    [stepCount, interval],
  );

  return { step, run };
}

interface LoadingSequenceProps {
  steps: string[];
  step: number;
  className?: string;
}

export function LoadingSequence({ steps, step, className }: LoadingSequenceProps) {
  const progress = ((step + 1) / steps.length) * 100;
  const done = step >= steps.length - 1;

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -12 }}
      transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
      className={cn(
        "relative overflow-hidden rounded-[2rem] border border-line/80 bg-white/80 px-6 py-14 text-center shadow-soft backdrop-blur sm:px-12 sm:py-16",
        className,
      )}
      role="status"
      aria-live="polite"
    >
      {/* Orb */}
      <div className="relative mx-auto flex h-36 w-36 items-center justify-center">
        {[0, 1, 2].map((i) => (
          <motion.span
            key={i}
            className="absolute inset-0 rounded-full border border-champagne/50"
            initial={{ scale: 0.6, opacity: 0 }}
            animate={{ scale: [0.6, 1.25], opacity: [0.7, 0] }}
            transition={{ duration: 2.4, repeat: Infinity, delay: i * 0.8, ease: "easeOut" }}
          />
        ))}
        <motion.span
          className="absolute inset-5 rounded-full"
          style={{
            background:
              "conic-gradient(from 0deg, rgba(201,169,110,0) 0deg, rgba(201,169,110,0.9) 120deg, rgba(201,169,110,0) 240deg)",
            WebkitMask: "radial-gradient(circle, transparent 62%, #000 63%)",
            mask: "radial-gradient(circle, transparent 62%, #000 63%)",
          }}
          animate={{ rotate: 360 }}
          transition={{ duration: 2.2, repeat: Infinity, ease: "linear" }}
        />
        <motion.span
          className="relative flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-b from-cream to-sand shadow-inner"
          animate={{ scale: done ? 1.08 : [1, 1.05, 1] }}
          transition={done ? { duration: 0.4 } : { duration: 2, repeat: Infinity, ease: "easeInOut" }}
        >
          <AnimatePresence mode="wait">
            {done ? (
              <motion.span key="done" initial={{ scale: 0 }} animate={{ scale: 1 }} className="text-gold">
                <Check className="h-6 w-6" strokeWidth={1.8} />
              </motion.span>
            ) : (
              <motion.span key="drop" exit={{ scale: 0 }} className="text-gold">
                <Droplet className="h-6 w-6" strokeWidth={1.4} />
              </motion.span>
            )}
          </AnimatePresence>
        </motion.span>
      </div>

      {/* Current step */}
      <div className="mt-10 h-10 overflow-hidden">
        <AnimatePresence mode="wait">
          <motion.p
            key={step}
            initial={{ y: 24, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: -24, opacity: 0 }}
            transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
            className="font-serif text-[1.9rem] italic leading-10 text-ink"
          >
            {steps[step]}
          </motion.p>
        </AnimatePresence>
      </div>

      {/* Progress */}
      <div className="mx-auto mt-8 h-px w-full max-w-sm overflow-hidden bg-sand">
        <motion.div
          className="h-full bg-champagne"
          initial={{ width: "0%" }}
          animate={{ width: `${progress}%` }}
          transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
        />
      </div>

      <ol className="mx-auto mt-8 grid max-w-md gap-2.5 text-left">
        {steps.map((label, i) => (
          <li
            key={label}
            className={cn(
              "flex items-center gap-3 text-[0.8rem] tracking-wide transition-colors duration-500",
              i < step || (done && i === step) ? "text-charcoal" : i === step ? "text-ink" : "text-stone/50",
            )}
          >
            <span
              className={cn(
                "flex h-5 w-5 shrink-0 items-center justify-center rounded-full border transition-all duration-500",
                i < step || done
                  ? "border-champagne bg-champagne text-ink"
                  : i === step
                    ? "border-champagne"
                    : "border-line",
              )}
            >
              {i < step || done ? (
                <Check className="h-3 w-3" strokeWidth={2.5} />
              ) : i === step ? (
                <motion.span
                  className="h-1.5 w-1.5 rounded-full bg-champagne"
                  animate={{ opacity: [1, 0.3, 1] }}
                  transition={{ duration: 1, repeat: Infinity }}
                />
              ) : null}
            </span>
            {label.replace("…", "")}
          </li>
        ))}
      </ol>
    </motion.div>
  );
}
