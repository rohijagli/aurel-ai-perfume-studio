"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { ArrowRight, Bookmark, RotateCcw, Sparkles } from "lucide-react";
import type { ScentResult } from "@/lib/types";
import { DIMENSIONS, hexToRgba, mixHex } from "@/lib/scent";
import { Button } from "./Button";
import { PerfumeBottle } from "./PerfumeBottle";

interface AIResultProps {
  result: ScentResult;
  mode: "generate" | "clone";
  onCustomize: () => void;
  onReset: () => void;
  onSave?: () => void;
}

const ease = [0.22, 1, 0.36, 1] as const;

function useCountUp(target: number, duration = 1400) {
  const [value, setValue] = useState(0);
  useEffect(() => {
    let raf = 0;
    const start = performance.now();
    const tick = (now: number) => {
      const t = Math.min(1, (now - start) / duration);
      setValue(Math.round(target * (1 - Math.pow(1 - t, 3))));
      if (t < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [target, duration]);
  return value;
}

function ConfidenceRing({ value, label }: { value: number; label: string }) {
  const shown = useCountUp(value);
  const r = 34;
  return (
    <div className="flex items-center gap-4">
      <div className="relative h-20 w-20 shrink-0">
        <svg viewBox="0 0 80 80" className="h-full w-full -rotate-90">
          <circle cx="40" cy="40" r={r} fill="none" stroke="var(--color-sand)" strokeWidth="3" />
          <motion.circle
            cx="40"
            cy="40"
            r={r}
            fill="none"
            stroke="var(--color-champagne)"
            strokeWidth="3"
            strokeLinecap="round"
            initial={{ pathLength: 0 }}
            animate={{ pathLength: value / 100 }}
            transition={{ duration: 1.4, ease, delay: 0.2 }}
          />
        </svg>
        <span className="absolute inset-0 flex items-center justify-center font-serif text-2xl text-ink">
          {shown}
          <span className="text-sm">%</span>
        </span>
      </div>
      <div>
        <p className="text-[0.65rem] font-semibold uppercase tracking-[0.22em] text-stone">{label}</p>
        <p className="mt-1 text-sm text-charcoal">{value >= 90 ? "Excellent match" : value >= 85 ? "Strong match" : "Good match"}</p>
      </div>
    </div>
  );
}

function NoteColumn({ title, notes, accord, delay }: { title: string; notes: string[]; accord?: string; delay: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.7, delay, ease }}
      className="border-t border-line pt-4"
    >
      <p className="text-[0.62rem] font-semibold uppercase tracking-[0.22em] text-gold">{title}</p>
      {accord && <p className="mt-2 font-serif text-xl text-ink">{accord}</p>}
      <ul className={accord ? "mt-1 space-y-0.5" : "mt-2 space-y-1"}>
        {notes.map((n) => (
          <li key={n} className={accord ? "text-[0.8rem] text-stone" : "font-serif text-xl leading-snug text-ink"}>
            {n}
          </li>
        ))}
      </ul>
    </motion.div>
  );
}

export function AIResult({ result, mode, onCustomize, onReset, onSave }: AIResultProps) {
  const isClone = mode === "clone";
  const tint = mixHex(result.color, "#f8f4ed", 0.8);
  const topDims = [...DIMENSIONS].sort((a, b) => result.profile[b.key] - result.profile[a.key]).slice(0, 3);

  return (
    <motion.section
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.9, ease }}
      className="overflow-hidden rounded-[2rem] border border-line/80 bg-white shadow-lift"
      aria-label={`${result.name} scent profile`}
    >
      <div className="grid lg:grid-cols-[0.9fr_1.1fr]">
        {/* Visual */}
        <div
          className="relative flex min-h-[380px] flex-col items-center justify-center overflow-hidden px-6 py-12"
          style={{
            background: `radial-gradient(70% 60% at 50% 60%, ${hexToRgba(result.color, 0.35)} 0%, transparent 70%), linear-gradient(180deg, #fbf8f3, ${tint})`,
          }}
        >
          <motion.span
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="absolute left-6 top-6 inline-flex items-center gap-2 rounded-full border border-ink/10 bg-white/70 px-3 py-1.5 text-[0.62rem] font-semibold uppercase tracking-[0.2em] text-charcoal backdrop-blur"
          >
            <Sparkles className="h-3 w-3 text-gold" />
            {isClone ? "AI Clone Analysis" : "AI Generated"}
          </motion.span>
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            transition={{ duration: 1.1, ease, delay: 0.15 }}
          >
            <PerfumeBottle name={result.name} color={result.color} size="lg" />
          </motion.div>
          <div className="mt-6 flex flex-wrap justify-center gap-2">
            {topDims.map((d) => (
              <span
                key={d.key}
                className="inline-flex items-center gap-1.5 rounded-full bg-white/70 px-3 py-1 text-[0.68rem] font-medium text-charcoal backdrop-blur"
              >
                <span className="h-1.5 w-1.5 rounded-full" style={{ backgroundColor: d.color }} />
                {d.label}
              </span>
            ))}
          </div>
        </div>

        {/* Details */}
        <div className="p-7 sm:p-10 lg:p-12">
          {isClone && result.reference && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.2 }}
              className="mb-6 flex items-center gap-3 rounded-2xl bg-cream/70 px-4 py-3"
            >
              <span className="text-[0.62rem] font-semibold uppercase tracking-[0.22em] text-stone">Reference</span>
              <span className="font-serif text-lg italic text-ink">“{result.reference}”</span>
            </motion.div>
          )}

          <p className="eyebrow">{isClone ? "Your AUREL interpretation" : "Your scent profile"}</p>
          <h2 className="display mt-3 overflow-hidden text-5xl uppercase tracking-[0.04em] sm:text-6xl">
            <motion.span
              className="block"
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              transition={{ duration: 1, ease, delay: 0.25 }}
            >
              {result.name}
            </motion.span>
          </h2>

          <div className="mt-6 flex flex-col gap-6 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <p className="text-[0.62rem] font-semibold uppercase tracking-[0.22em] text-stone">Family</p>
              <p className="mt-1 font-serif text-2xl text-ink">{result.family}</p>
            </div>
            <ConfidenceRing value={result.confidence} label={isClone ? "Similarity" : "AI Confidence"} />
          </div>

          <div className="mt-8 grid grid-cols-1 gap-5 sm:grid-cols-3">
            <NoteColumn title="Top Notes" notes={result.topNotes} accord={result.accords?.top} delay={0.45} />
            <NoteColumn title="Heart Notes" notes={result.heartNotes} accord={result.accords?.heart} delay={0.55} />
            <NoteColumn title="Base Notes" notes={result.baseNotes} accord={result.accords?.base} delay={0.65} />
          </div>

          <motion.blockquote
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.85, duration: 0.8 }}
            className="mt-8 border-l-2 border-champagne pl-5 font-serif text-[1.35rem] italic leading-snug text-charcoal"
          >
            “{result.description}”
          </motion.blockquote>

          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1, duration: 0.6 }}
            className="mt-10 flex flex-col gap-3 sm:flex-row sm:flex-wrap"
          >
            <Button onClick={onCustomize} icon={<ArrowRight className="h-4 w-4" />} className="w-full sm:w-auto">
              {isClone ? "Customize the Clone" : "Customize This Scent"}
            </Button>
            {onSave && (
              <Button
                variant="secondary"
                onClick={onSave}
                iconLeft={<Bookmark className="h-4 w-4" strokeWidth={1.6} />}
                className="w-full sm:w-auto"
              >
                Save
              </Button>
            )}
            <Button
              variant="ghost"
              onClick={onReset}
              iconLeft={<RotateCcw className="h-4 w-4" strokeWidth={1.6} />}
              className="w-full sm:w-auto"
            >
              {isClone ? "Analyze another" : "Try another"}
            </Button>
          </motion.div>
        </div>
      </div>
    </motion.section>
  );
}
