"use client";

import Link from "next/link";
import { AnimatePresence, motion } from "framer-motion";
import { Check, X } from "lucide-react";
import { useStudio } from "@/context/StudioContext";

export function Toast() {
  const { toast, dismissToast } = useStudio();

  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-5 z-[60] flex justify-center px-4" aria-live="polite">
      <AnimatePresence>
        {toast && (
          <motion.div
            key={toast.id}
            role="status"
            initial={{ opacity: 0, y: 24, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 16, scale: 0.98 }}
            transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
            className="pointer-events-auto flex w-full max-w-md items-center gap-4 rounded-2xl bg-ink px-5 py-4 text-ivory shadow-lift"
          >
            <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-champagne text-ink">
              <Check className="h-4 w-4" strokeWidth={2.2} />
            </span>
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-medium">{toast.message}</p>
              {toast.detail && <p className="mt-0.5 text-xs text-ivory/60">{toast.detail}</p>}
            </div>
            {toast.href && (
              <Link
                href={toast.href}
                onClick={dismissToast}
                className="shrink-0 text-[0.7rem] font-semibold uppercase tracking-[0.16em] text-champagne hover:text-ivory"
              >
                {toast.hrefLabel ?? "View"}
              </Link>
            )}
            <button
              type="button"
              onClick={dismissToast}
              aria-label="Dismiss notification"
              className="shrink-0 rounded-full p-1 text-ivory/50 transition-colors hover:text-ivory"
            >
              <X className="h-4 w-4" />
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
