"use client";

import { motion } from "framer-motion";
import { hexToRgba, mixHex } from "@/lib/scent";
import { cn } from "@/lib/utils";

type BottleSize = "sm" | "md" | "lg" | "xl";

const SIZES: Record<BottleSize, { w: number; h: number }> = {
  sm: { w: 84, h: 110 },
  md: { w: 136, h: 178 },
  lg: { w: 188, h: 246 },
  xl: { w: 232, h: 304 },
};

export interface PerfumeBottleProps {
  name: string;
  /** Hex colour of the juice. */
  color?: string;
  size?: BottleSize;
  /** Gentle float animation. */
  float?: boolean;
  subtitle?: string;
  className?: string;
}

/**
 * Reusable CSS glass bottle: gold cap, tinted juice, reflections, label.
 *
 *   <PerfumeBottle name="NOIR ÉCLAT" color="#5B3A2A" size="lg" />
 */
export function PerfumeBottle({
  name,
  color = "#B98A55",
  size = "md",
  float = true,
  subtitle = "Eau de Parfum",
  className,
}: PerfumeBottleProps) {
  const { w, h } = SIZES[size];
  const capW = w * 0.44;
  const capH = h * 0.27;
  const collarW = capW * 0.82;
  const collarH = Math.max(5, h * 0.05);
  const radius = w * 0.1;
  const showSubtitle = size !== "sm";
  const deep = mixHex(color, "#1b1815", 0.35);
  const light = mixHex(color, "#ffffff", 0.35);

  return (
    <div
      role="img"
      aria-label={`${name} perfume bottle`}
      className={cn("relative flex select-none flex-col items-center", className)}
      style={{ width: w }}
    >
      <motion.div
        className="relative z-10 flex flex-col items-center"
        animate={float ? { y: [0, -9, 0] } : undefined}
        transition={float ? { duration: 6, repeat: Infinity, ease: "easeInOut" } : undefined}
      >
        {/* Cap */}
        <div
          className="relative overflow-hidden"
          style={{
            width: capW,
            height: capH,
            borderRadius: `${w * 0.035}px ${w * 0.035}px 2px 2px`,
            background:
              "linear-gradient(90deg,#7d5f33 0%,#c9a464 16%,#f4e4c1 34%,#d8b678 50%,#a8874e 70%,#cfae72 86%,#8a6a3b 100%)",
            boxShadow: "inset 0 -3px 6px rgba(0,0,0,0.18), 0 3px 8px rgba(80,60,30,0.2)",
          }}
        >
          <span className="absolute inset-x-0 top-0 h-[2px] bg-white/60" />
          {/* engraved ring */}
          <span className="absolute inset-x-0 bottom-[18%] h-px bg-black/15" />
          <span className="absolute inset-x-0 bottom-[calc(18%-1px)] h-px bg-white/40" />
        </div>

        {/* Collar */}
        <div
          style={{
            width: collarW,
            height: collarH,
            background: "linear-gradient(90deg,#6f532c,#b8955a 30%,#e9d3a4 45%,#9c7c46 70%,#6f532c)",
          }}
        />

        {/* Glass body */}
        <div
          className="relative overflow-hidden"
          style={{
            width: w,
            height: h,
            borderRadius: radius,
            background:
              "linear-gradient(155deg, rgba(255,255,255,0.85) 0%, rgba(255,255,255,0.35) 38%, rgba(255,255,255,0.55) 100%)",
            border: "1px solid rgba(255,255,255,0.95)",
            boxShadow: `inset 0 0 0 1px rgba(27,24,21,0.06), inset 0 -${h * 0.12}px ${h * 0.2}px ${hexToRgba(
              color,
              0.25,
            )}, 0 ${h * 0.16}px ${h * 0.24}px -${h * 0.12}px ${hexToRgba(color, 0.6)}, 0 10px 24px -14px rgba(27,24,21,0.35)`,
          }}
        >
          {/* Juice */}
          <div
            className="absolute inset-x-[5%] bottom-[5%] overflow-hidden transition-[background-color] duration-700"
            style={{
              top: "18%",
              borderRadius: radius * 0.7,
              backgroundColor: color,
            }}
          >
            <div
              className="absolute inset-0"
              style={{
                background: `linear-gradient(180deg, ${hexToRgba(light, 0.55)} 0%, transparent 35%, ${hexToRgba(
                  deep,
                  0.55,
                )} 100%)`,
              }}
            />
            {/* meniscus */}
            <div className="absolute inset-x-0 top-0 h-[3px] bg-white/45" />
          </div>

          {/* Thick-glass inner edge */}
          <div
            className="pointer-events-none absolute inset-[4%] border border-white/50"
            style={{ borderRadius: radius * 0.75 }}
          />

          {/* Reflections */}
          <div className="pointer-events-none absolute bottom-[10%] left-[9%] top-[7%] w-[8%] rounded-full bg-gradient-to-b from-white/85 via-white/35 to-transparent" />
          <div className="pointer-events-none absolute bottom-[30%] left-[20%] top-[9%] w-[2%] rounded-full bg-white/40" />
          <div className="pointer-events-none absolute bottom-[14%] right-[9%] top-[22%] w-[3%] rounded-full bg-gradient-to-b from-transparent via-white/50 to-transparent" />

          {/* Label */}
          <div
            className="absolute left-1/2 top-[56%] flex w-[64%] -translate-x-1/2 -translate-y-1/2 flex-col items-center justify-center border border-champagne/60 bg-ivory/92 text-center shadow-[0_2px_10px_rgba(27,24,21,0.12)]"
            style={{ padding: `${h * 0.05}px ${w * 0.04}px` }}
          >
            <span
              className="font-sans font-semibold uppercase text-gold"
              style={{ fontSize: Math.max(5, w * 0.042), letterSpacing: "0.38em", paddingLeft: "0.38em" }}
            >
              Aurel
            </span>
            <span className="mx-auto my-[3%] block h-px w-1/3 bg-champagne/70" />
            <span
              className="font-serif uppercase leading-[1.05] text-ink"
              style={{ fontSize: Math.max(8, w * 0.088), letterSpacing: "0.08em" }}
            >
              {name}
            </span>
            {showSubtitle && (
              <span
                className="mt-[4%] font-sans uppercase text-stone"
                style={{ fontSize: Math.max(5, w * 0.036), letterSpacing: "0.28em" }}
              >
                {subtitle}
              </span>
            )}
          </div>
        </div>
      </motion.div>

      {/* Ground shadow */}
      <motion.div
        aria-hidden
        className="rounded-[50%] bg-ink/25 blur-md"
        style={{ width: w * 0.9, height: Math.max(8, h * 0.06), marginTop: h * 0.06 }}
        animate={float ? { scaleX: [1, 0.88, 1], opacity: [0.55, 0.38, 0.55] } : undefined}
        transition={float ? { duration: 6, repeat: Infinity, ease: "easeInOut" } : undefined}
      />
    </div>
  );
}
