"use client";

import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ImagePlus, X } from "lucide-react";
import { cn } from "@/lib/utils";
import { PerfumeBottle } from "./PerfumeBottle";

export type UploadSelection = { kind: "file"; file: File } | { kind: "sample" } | null;

interface UploadBoxProps {
  value: UploadSelection;
  onChange: (value: UploadSelection) => void;
  disabled?: boolean;
}

const MAX_SIZE_MB = 10;

/**
 * Drag-and-drop image picker. No recognition happens client-side;
 * the file is handed to `clonePerfume()` which is mocked in the prototype.
 */
export function UploadBox({ value, onChange, disabled }: UploadBoxProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [dragging, setDragging] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [preview, setPreview] = useState<string | null>(null);

  useEffect(() => {
    if (value?.kind !== "file") {
      setPreview(null);
      return;
    }
    const url = URL.createObjectURL(value.file);
    setPreview(url);
    return () => URL.revokeObjectURL(url);
  }, [value]);

  const accept = (file: File | undefined) => {
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      setError("Please choose an image file (JPG, PNG or WEBP).");
      return;
    }
    if (file.size > MAX_SIZE_MB * 1024 * 1024) {
      setError(`Images must be smaller than ${MAX_SIZE_MB} MB.`);
      return;
    }
    setError(null);
    onChange({ kind: "file", file });
  };

  const fileName = value?.kind === "file" ? value.file.name : "sample-oud-bottle.jpg";

  return (
    <div>
      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        className="sr-only"
        tabIndex={-1}
        aria-hidden
        onChange={(e) => {
          accept(e.target.files?.[0]);
          e.target.value = "";
        }}
      />

      <AnimatePresence mode="wait" initial={false}>
        {value ? (
          <motion.div
            key="preview"
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.98 }}
            transition={{ duration: 0.4 }}
            className="relative flex h-64 items-center justify-center overflow-hidden rounded-[1.5rem] border border-line bg-gradient-to-b from-cream/60 to-sand/70"
          >
            {preview ? (
              // eslint-disable-next-line @next/next/no-img-element -- local object URL preview
              <img src={preview} alt="Uploaded perfume" className="h-full w-full object-contain p-4" />
            ) : (
              <PerfumeBottle name="Oud" color="#6E4A2F" size="sm" float={false} subtitle="" />
            )}
            {/* scan line */}
            <motion.span
              aria-hidden
              className="pointer-events-none absolute inset-x-6 h-px bg-gradient-to-r from-transparent via-champagne to-transparent"
              animate={{ top: ["12%", "88%", "12%"] }}
              transition={{ duration: 3.2, repeat: Infinity, ease: "easeInOut" }}
            />
            <div className="absolute inset-x-3 bottom-3 flex items-center justify-between rounded-full bg-white/85 py-1.5 pl-4 pr-1.5 backdrop-blur">
              <span className="truncate text-xs text-charcoal">{fileName}</span>
              <button
                type="button"
                disabled={disabled}
                onClick={() => onChange(null)}
                aria-label="Remove image"
                className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-stone transition-colors hover:bg-ink/5 hover:text-ink disabled:opacity-40"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            </div>
          </motion.div>
        ) : (
          <motion.div
            key="drop"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            role="button"
            tabIndex={0}
            aria-label="Upload a perfume image"
            onClick={() => !disabled && inputRef.current?.click()}
            onKeyDown={(e) => {
              if ((e.key === "Enter" || e.key === " ") && !disabled) {
                e.preventDefault();
                inputRef.current?.click();
              }
            }}
            onDragOver={(e) => {
              e.preventDefault();
              setDragging(true);
            }}
            onDragLeave={() => setDragging(false)}
            onDrop={(e) => {
              e.preventDefault();
              setDragging(false);
              if (!disabled) accept(e.dataTransfer.files?.[0]);
            }}
            className={cn(
              "flex h-64 cursor-pointer flex-col items-center justify-center rounded-[1.5rem] border border-dashed px-6 text-center transition-all duration-300",
              dragging ? "scale-[1.01] border-champagne bg-champagne/10" : "border-ink/20 bg-ivory/60 hover:border-champagne hover:bg-cream/60",
            )}
          >
            <motion.span
              animate={dragging ? { y: -4, scale: 1.08 } : { y: 0, scale: 1 }}
              className="flex h-14 w-14 items-center justify-center rounded-full border border-champagne/50 bg-white text-gold"
            >
              <ImagePlus className="h-6 w-6" strokeWidth={1.3} />
            </motion.span>
            <p className="mt-5 font-serif text-2xl text-ink">{dragging ? "Release to upload" : "Drop a bottle photo here"}</p>
            <p className="mt-1.5 text-xs tracking-wide text-stone">JPG, PNG or WEBP · up to {MAX_SIZE_MB} MB</p>
            <span className="mt-5 rounded-full border border-ink/15 bg-white px-5 py-2 text-[0.68rem] font-semibold uppercase tracking-[0.18em] text-ink">
              Choose Image
            </span>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="mt-3 flex min-h-5 items-center justify-between gap-3">
        {error ? (
          <p className="text-xs text-[#a3412f]" role="alert">
            {error}
          </p>
        ) : (
          <span />
        )}
        {!value && (
          <button
            type="button"
            disabled={disabled}
            onClick={() => {
              setError(null);
              onChange({ kind: "sample" });
            }}
            className="shrink-0 text-xs text-stone underline decoration-line underline-offset-4 transition-colors hover:text-ink"
          >
            No photo? Use a sample image
          </button>
        )}
      </div>
    </div>
  );
}
