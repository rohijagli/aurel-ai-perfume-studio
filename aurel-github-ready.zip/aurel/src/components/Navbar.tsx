"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowRight, Menu, ShoppingBag, X } from "lucide-react";
import { useStudio } from "@/context/StudioContext";
import { cn } from "@/lib/utils";

export const NAV_LINKS = [
  { href: "/ai-perfume", label: "AI Perfume" },
  { href: "/clone", label: "Clone" },
  { href: "/explore", label: "Explore" },
  { href: "/my-fragrances", label: "My Fragrances" },
];

export function Logo({ className }: { className?: string }) {
  return (
    <Link href="/" aria-label="AUREL home" className={cn("group flex items-baseline gap-2", className)}>
      <span className="font-serif text-[1.65rem] font-medium tracking-[0.34em] text-ink">AUREL</span>
      <span className="hidden h-1.5 w-1.5 rounded-full bg-champagne transition-transform duration-500 group-hover:scale-150 sm:block" />
    </Link>
  );
}

export function Navbar() {
  const pathname = usePathname();
  const { cartCount } = useStudio();
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // Close the mobile menu on navigation.
  useEffect(() => setOpen(false), [pathname]);

  // Lock scroll while the mobile menu is open.
  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  const isActive = (href: string) => pathname === href || pathname.startsWith(href + "/");

  return (
    <>
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-50 transition-all duration-500",
        scrolled || open
          ? "border-b border-line/80 bg-ivory/85 backdrop-blur-xl"
          : "border-b border-transparent bg-transparent",
      )}
    >
      <nav className="container-luxe flex h-20 items-center justify-between" aria-label="Main">
        <Logo />

        <ul className="hidden items-center gap-9 lg:flex">
          {NAV_LINKS.map((link) => (
            <li key={link.href}>
              <Link
                href={link.href}
                aria-current={isActive(link.href) ? "page" : undefined}
                className={cn(
                  "relative py-2 text-[0.8rem] font-medium tracking-[0.08em] transition-colors",
                  isActive(link.href) ? "text-ink" : "text-stone hover:text-ink",
                )}
              >
                {link.label}
                {isActive(link.href) && (
                  <motion.span
                    layoutId="nav-underline"
                    className="absolute -bottom-0.5 left-0 right-0 h-px bg-champagne"
                    transition={{ type: "spring", stiffness: 380, damping: 32 }}
                  />
                )}
              </Link>
            </li>
          ))}
        </ul>

        <div className="flex items-center gap-2 sm:gap-3">
          <Link
            href="/my-fragrances"
            aria-label={`Bag, ${cartCount} items`}
            className="relative flex h-10 w-10 items-center justify-center rounded-full text-ink transition-colors hover:bg-ink/5"
          >
            <ShoppingBag className="h-[18px] w-[18px]" strokeWidth={1.5} />
            <AnimatePresence>
              {cartCount > 0 && (
                <motion.span
                  key={cartCount}
                  initial={{ scale: 0.4, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  exit={{ scale: 0.4, opacity: 0 }}
                  className="absolute right-1 top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-champagne px-1 text-[0.6rem] font-bold text-ink"
                >
                  {cartCount}
                </motion.span>
              )}
            </AnimatePresence>
          </Link>

          <Link
            href="/ai-perfume"
            className="group hidden h-10 items-center gap-2 rounded-full bg-ink px-5 text-[0.72rem] font-semibold uppercase tracking-[0.16em] text-ivory transition-colors hover:bg-charcoal md:inline-flex"
          >
            Create Your Scent
            <ArrowRight className="h-3.5 w-3.5 transition-transform duration-500 group-hover:translate-x-0.5" />
          </Link>

          <button
            type="button"
            onClick={() => setOpen((o) => !o)}
            aria-expanded={open}
            aria-controls="mobile-menu"
            aria-label={open ? "Close menu" : "Open menu"}
            className="flex h-10 w-10 items-center justify-center rounded-full text-ink transition-colors hover:bg-ink/5 lg:hidden"
          >
            <AnimatePresence mode="wait" initial={false}>
              <motion.span
                key={open ? "close" : "open"}
                initial={{ rotate: -90, opacity: 0 }}
                animate={{ rotate: 0, opacity: 1 }}
                exit={{ rotate: 90, opacity: 0 }}
                transition={{ duration: 0.2 }}
              >
                {open ? <X className="h-5 w-5" strokeWidth={1.5} /> : <Menu className="h-5 w-5" strokeWidth={1.5} />}
              </motion.span>
            </AnimatePresence>
          </button>
        </div>
      </nav>

    </header>

      {/* Mobile menu */}
    <AnimatePresence>
      {open && (
        <motion.div
          id="mobile-menu"
          key="mobile-menu"
          initial={{ opacity: 0, y: -16 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -16 }}
          transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
          className="fixed inset-x-0 bottom-0 top-20 z-40 overflow-y-auto border-t border-line/70 bg-ivory lg:hidden"
        >
          <div className="container-luxe flex h-full flex-col justify-between pb-10 pt-8">
            <ul className="space-y-1">
              {[{ href: "/", label: "Home" }, ...NAV_LINKS].map((link, i) => (
                <motion.li
                  key={link.href}
                  initial={{ opacity: 0, y: 16 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.08 + i * 0.06, duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
                >
                  <Link
                    href={link.href}
                    onClick={() => setOpen(false)}
                    className={cn(
                      "flex items-center justify-between border-b border-line/70 py-4 font-serif text-[2rem] leading-none",
                      (link.href === "/" ? pathname === "/" : isActive(link.href)) ? "text-ink" : "text-ink/55",
                    )}
                  >
                    {link.label}
                    <span className="font-sans text-[0.65rem] tracking-[0.3em] text-gold">0{i + 1}</span>
                  </Link>
                </motion.li>
              ))}
            </ul>
            <motion.div
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4, duration: 0.5 }}
              className="space-y-5"
            >
              <Link
                href="/ai-perfume"
                onClick={() => setOpen(false)}
                className="flex h-13 items-center justify-center gap-2 rounded-full bg-ink py-4 text-[0.78rem] font-semibold uppercase tracking-[0.18em] text-ivory"
              >
                Create Your Scent <ArrowRight className="h-4 w-4" />
              </Link>
              <p className="text-center font-serif text-lg italic text-stone">Your scent, imagined.</p>
            </motion.div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
    </>
  );
}
