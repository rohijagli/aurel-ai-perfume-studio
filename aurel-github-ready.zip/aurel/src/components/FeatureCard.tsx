"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowUpRight, type LucideIcon } from "lucide-react";

interface FeatureCardProps {
  index: string;
  title: string;
  text: string;
  href: string;
  cta: string;
  icon: LucideIcon;
  delay?: number;
}

export function FeatureCard({ index, title, text, href, cta, icon: Icon, delay = 0 }: FeatureCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 28 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{ duration: 0.9, delay, ease: [0.22, 1, 0.36, 1] }}
      whileHover={{ y: -6 }}
      className="h-full"
    >
      <Link
        href={href}
        className="group relative flex h-full flex-col overflow-hidden rounded-[1.75rem] border border-line/80 bg-white p-8 shadow-soft transition-shadow duration-500 hover:shadow-lift sm:p-10"
      >
        {/* champagne glow on hover */}
        <span className="pointer-events-none absolute -right-20 -top-20 h-56 w-56 rounded-full bg-champagne/0 blur-3xl transition-colors duration-700 group-hover:bg-champagne/25" />

        <div className="flex items-center justify-between">
          <span className="flex h-12 w-12 items-center justify-center rounded-full border border-champagne/50 bg-cream text-gold">
            <Icon className="h-5 w-5" strokeWidth={1.4} />
          </span>
          <span className="font-serif text-lg text-stone">{index}</span>
        </div>

        <h3 className="mt-12 font-serif text-[2.4rem] leading-none text-ink">{title}</h3>
        <p className="mt-4 max-w-xs text-[0.95rem] leading-relaxed text-charcoal/75">{text}</p>

        <span className="mt-auto flex items-center gap-2 pt-10 text-[0.72rem] font-semibold uppercase tracking-[0.18em] text-ink">
          {cta}
          <ArrowUpRight className="h-4 w-4 transition-transform duration-500 group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
        </span>
      </Link>
    </motion.div>
  );
}
