"use client";

import { motion } from "framer-motion";
import { Heart, SlidersHorizontal } from "lucide-react";
import type { Perfume } from "@/lib/types";
import { hexToRgba, mixHex } from "@/lib/scent";
import { cn, formatPrice } from "@/lib/utils";
import { useStudio } from "@/context/StudioContext";
import { PerfumeBottle } from "./PerfumeBottle";

interface PerfumeCardProps {
  perfume: Perfume;
  onCustomize: (perfume: Perfume) => void;
  /** Small label in the top-left of the visual, e.g. "AI Creation". */
  badge?: string;
  /** Secondary line under the name, e.g. a date or "Inspired by …". */
  meta?: string;
  index?: number;
  hideDescription?: boolean;
}

export function PerfumeCard({ perfume, onCustomize, badge, meta, index = 0, hideDescription }: PerfumeCardProps) {
  const { isFavorite, toggleFavorite } = useStudio();
  const favorite = isFavorite(perfume.id);
  const notes = [perfume.topNotes[0], perfume.heartNotes[0], perfume.baseNotes[0]].filter(Boolean);
  const tint = mixHex(perfume.color, "#f8f4ed", 0.82);

  return (
    <motion.article
      layout
      initial={{ opacity: 0, y: 24 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.97 }}
      transition={{ duration: 0.6, delay: Math.min(index, 8) * 0.05, ease: [0.22, 1, 0.36, 1] }}
      whileHover={{ y: -6 }}
      className="group flex h-full flex-col overflow-hidden rounded-[1.75rem] border border-line/80 bg-white shadow-soft transition-shadow duration-500 hover:shadow-lift"
    >
      {/* Visual */}
      <div
        className="relative flex h-64 items-end justify-center overflow-hidden pb-5"
        style={{
          background: `radial-gradient(120% 90% at 50% 100%, ${hexToRgba(perfume.color, 0.28)} 0%, transparent 60%), linear-gradient(180deg, #fbf8f3 0%, ${tint} 100%)`,
        }}
      >
        <div className="absolute inset-x-0 top-0 flex items-start justify-between p-4">
          <span className="rounded-full border border-ink/10 bg-white/70 px-3 py-1 text-[0.62rem] font-semibold uppercase tracking-[0.2em] text-charcoal backdrop-blur">
            {badge ?? perfume.family}
          </span>
          <button
            type="button"
            onClick={() => toggleFavorite(perfume.id, perfume.name)}
            aria-pressed={favorite}
            aria-label={favorite ? `Remove ${perfume.name} from favorites` : `Add ${perfume.name} to favorites`}
            className="flex h-9 w-9 items-center justify-center rounded-full bg-white/70 backdrop-blur transition-transform hover:scale-110"
          >
            <Heart
              className={cn("h-4 w-4 transition-colors", favorite ? "fill-champagne text-champagne" : "text-charcoal")}
              strokeWidth={1.6}
            />
          </button>
        </div>
        <div className="transition-transform duration-700 ease-[cubic-bezier(0.22,1,0.36,1)] group-hover:scale-[1.04]">
          <PerfumeBottle name={perfume.name} color={perfume.color} size="sm" float={false} />
        </div>
      </div>

      {/* Body */}
      <div className="flex flex-1 flex-col p-6">
        <div className="flex items-start justify-between gap-4">
          <div className="min-w-0">
            <h3 className="font-serif text-[1.65rem] leading-tight text-ink">{perfume.name}</h3>
            <p className="mt-1 text-[0.7rem] font-semibold uppercase tracking-[0.18em] text-gold">
              {meta ?? perfume.family}
            </p>
          </div>
          <p className="shrink-0 pt-1.5 text-sm font-medium text-charcoal">{formatPrice(perfume.price)}</p>
        </div>

        <p className="mt-4 text-[0.78rem] tracking-wide text-stone">{notes.join(" · ")}</p>

        {!hideDescription && (
          <p className="mt-3 line-clamp-2 text-sm leading-relaxed text-charcoal/80">{perfume.description}</p>
        )}

        <div className="mt-auto pt-6">
          <button
            type="button"
            onClick={() => onCustomize(perfume)}
            className="group/btn flex w-full items-center justify-center gap-2 rounded-full border border-ink/15 py-3 text-[0.72rem] font-semibold uppercase tracking-[0.18em] text-ink transition-all duration-300 hover:border-ink hover:bg-ink hover:text-ivory"
          >
            <SlidersHorizontal className="h-3.5 w-3.5" strokeWidth={1.8} />
            Customize
          </button>
        </div>
      </div>
    </motion.article>
  );
}
