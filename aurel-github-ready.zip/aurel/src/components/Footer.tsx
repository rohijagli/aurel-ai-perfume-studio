import Link from "next/link";
import { Logo } from "./Navbar";

const COLUMNS = [
  {
    title: "Studio",
    links: [
      { href: "/ai-perfume", label: "AI Perfume" },
      { href: "/clone", label: "Clone a Perfume" },
      { href: "/customize", label: "Customize" },
    ],
  },
  {
    title: "Discover",
    links: [
      { href: "/explore", label: "Explore" },
      { href: "/my-fragrances", label: "My Fragrances" },
      { href: "/", label: "Our Story" },
    ],
  },
];

export function Footer() {
  return (
    <footer className="mt-28 border-t border-line bg-cream/50">
      <div className="container-luxe grid gap-12 py-16 md:grid-cols-[1.4fr_1fr_1fr_1.2fr]">
        <div className="space-y-5">
          <Logo />
          <p className="max-w-xs font-serif text-2xl italic leading-snug text-charcoal">Your scent, imagined.</p>
        </div>

        {COLUMNS.map((col) => (
          <div key={col.title}>
            <p className="eyebrow mb-5">{col.title}</p>
            <ul className="space-y-3">
              {col.links.map((l) => (
                <li key={l.label}>
                  <Link href={l.href} className="text-sm text-charcoal/80 transition-colors hover:text-ink">
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        ))}

        <div>
          <p className="eyebrow mb-5">The Atelier</p>
          <p className="text-sm leading-relaxed text-charcoal/80">
            Every AUREL fragrance is composed digitally and blended to order in small batches.
          </p>
        </div>
      </div>

      <div className="border-t border-line">
        <div className="container-luxe flex flex-col gap-3 py-6 text-[0.72rem] tracking-wide text-stone sm:flex-row sm:items-center sm:justify-between">
          <p>© {new Date().getFullYear()} AUREL — AI Perfume Studio</p>
          <p>Prototype for demonstration · AI results are simulated with sample data.</p>
        </div>
      </div>
    </footer>
  );
}
