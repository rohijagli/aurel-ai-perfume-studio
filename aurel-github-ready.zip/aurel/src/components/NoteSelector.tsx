"use client";

import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Check, Info } from "lucide-react";
import type { NoteTier } from "@/lib/types";
import { MAX_SELECTED_NOTES, NOTE_LIBRARY, TIER_DESCRIPTIONS, TIER_LABELS } from "@/data/notes";
import { cn } from "@/lib/utils";

interface NoteSelectorProps {
  selected: string[];
  onChange: (next: string[]) => void;
}

const TIERS: NoteTier[] = ["top", "heart", "base"];

export function NoteSelector({ selected, onChange }: NoteSelectorProps) {
  const [limitHit, setLimitHit] = useState(0);
  const full = selected.length >= MAX_SELECTED_NOTES;

  const toggle = (name: string) => {
    if (selected.includes(name)) {
      onChange(selected.filter((n) => n !== name));
      return;
    }
    if (full) {
      setLimitHit((n) => n + 1);
      return;
    }
    onChange([...selected, name]);
  };

  return (
    <div>
      <div className="mb-6 flex items-end justify-between gap-4">
        <div>
          <p className="eyebrow">Note Pyramid</p>
          <p className="mt-2 text-sm text-stone">Choose up to {MAX_SELECTED_NOTES} notes across the pyramid.</p>
        </div>
        <motion.div
          key={limitHit}
          animate={limitHit ? { x: [0, -6, 6, -4, 4, 0] } : undefined}
          transition={{ duration: 0.45 }}
          className="flex shrink-0 items-center gap-2"
          aria-live="polite"
        >
          <div className="flex gap-1" aria-hidden>
            {Array.from({ length: MAX_SELECTED_NOTES }).map((_, i) => (
              <span
                key={i}
                className={cn(
                  "h-1.5 w-4 rounded-full transition-colors duration-300",
                  i < selected.length ? "bg-champagne" : "bg-sand",
                )}
              />
            ))}
          </div>
          <span className="text-xs font-semibold tabular-nums text-charcoal">
            {selected.length}/{MAX_SELECTED_NOTES}
          </span>
        </motion.div>
      </div>

      <div className="space-y-6">
        {TIERS.map((tier) => (
          <fieldset key={tier}>
            <legend className="mb-3 flex w-full items-baseline justify-between">
              <span className="font-serif text-xl text-ink">{TIER_LABELS[tier]}</span>
              <span className="text-[0.68rem] tracking-wide text-stone">{TIER_DESCRIPTIONS[tier]}</span>
            </legend>
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
              {NOTE_LIBRARY[tier].map((note) => {
                const active = selected.includes(note.name);
                const blocked = !active && full;
                return (
                  <motion.button
                    key={note.name}
                    type="button"
                    onClick={() => toggle(note.name)}
                    aria-pressed={active}
                    whileTap={{ scale: 0.97 }}
                    className={cn(
                      "group relative flex items-center justify-between gap-2 rounded-2xl border px-4 py-3 text-left transition-all duration-300",
                      active
                        ? "border-ink bg-ink text-ivory shadow-[0_8px_20px_-12px_rgba(27,24,21,0.6)]"
                        : blocked
                          ? "border-line bg-white/50 text-ink/40"
                          : "border-line bg-white text-ink hover:border-champagne hover:bg-cream/40",
                    )}
                  >
                    <span className="min-w-0">
                      <span className="block truncate text-sm font-medium">{note.name}</span>
                      <span className={cn("block truncate text-[0.68rem]", active ? "text-ivory/60" : "text-stone")}>
                        {note.hint}
                      </span>
                    </span>
                    <span
                      className={cn(
                        "flex h-5 w-5 shrink-0 items-center justify-center rounded-full border transition-all duration-300",
                        active ? "border-champagne bg-champagne text-ink" : "border-line",
                      )}
                    >
                      {active && <Check className="h-3 w-3" strokeWidth={2.6} />}
                    </span>
                  </motion.button>
                );
              })}
            </div>
          </fieldset>
        ))}
      </div>

      <AnimatePresence>
        {full && (
          <motion.p
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="mt-4 flex items-center gap-2 overflow-hidden text-xs text-stone"
          >
            <Info className="h-3.5 w-3.5 shrink-0 text-gold" />
            Your pyramid is complete. Deselect a note to swap it for another.
          </motion.p>
        )}
      </AnimatePresence>
    </div>
  );
}
