"use client";

import { motion } from "framer-motion";
import { RevealLines } from "./Reveal";
import { cn } from "@/lib/utils";

interface PageHeaderProps {
  eyebrow: string;
  lines: React.ReactNode[];
  intro?: React.ReactNode;
  align?: "left" | "center";
  className?: string;
}

/** Editorial page heading used at the top of each studio page. */
export function PageHeader({ eyebrow, lines, intro, align = "left", className }: PageHeaderProps) {
  const centered = align === "center";
  return (
    <header className={cn("pb-10 pt-12 sm:pt-16", centered && "text-center", className)}>
      <motion.p
        className="eyebrow"
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        {eyebrow}
      </motion.p>
      <h1 className="display mt-5 text-[2.9rem] sm:text-6xl lg:text-[4.75rem]">
        <RevealLines lines={lines} animateOnMount delay={0.1} />
      </h1>
      {intro && (
        <motion.p
          className={cn("mt-6 max-w-xl text-base leading-relaxed text-charcoal/75 sm:text-lg", centered && "mx-auto")}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
        >
          {intro}
        </motion.p>
      )}
    </header>
  );
}
