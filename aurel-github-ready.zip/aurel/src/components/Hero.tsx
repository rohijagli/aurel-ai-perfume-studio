"use client";

import { motion } from "framer-motion";
import { ArrowRight, Sparkles } from "lucide-react";
import { Button } from "./Button";
import { PerfumeBottle } from "./PerfumeBottle";
import { RevealLines } from "./Reveal";

const ease = [0.22, 1, 0.36, 1] as const;

const FLOATING_NOTES = [
  { label: "Bergamot", tier: "Top", className: "left-[2%] top-[22%]", delay: 0.9, color: "#E9C46A" },
  { label: "Rose", tier: "Heart", className: "right-[0%] top-[40%]", delay: 1.05, color: "#D99AA5" },
  { label: "Oud", tier: "Base", className: "left-[6%] bottom-[16%]", delay: 1.2, color: "#7E5D3F" },
];

export function Hero() {
  return (
    <section className="container-luxe relative grid items-center gap-14 pb-16 pt-10 sm:pt-14 lg:min-h-[calc(100vh-5rem)] lg:grid-cols-[1.1fr_0.9fr] lg:gap-8 lg:pb-24 lg:pt-0">
      {/* Copy */}
      <div className="relative z-10 order-2 lg:order-1">
        <motion.p
          className="eyebrow flex items-center gap-3"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease }}
        >
          <span className="h-px w-8 bg-champagne" />
          AI Perfume Studio
        </motion.p>

        <h1 className="display mt-7 text-[3.6rem] sm:text-[5.5rem] lg:text-[6.8rem] xl:text-[7.6rem]">
          <RevealLines
            animateOnMount
            delay={0.15}
            lines={[
              "Your scent,",
              <em key="imagined" className="font-serif italic text-gold">
                imagined.
              </em>,
            ]}
          />
        </h1>

        <motion.p
          className="mt-8 max-w-md text-base leading-relaxed text-charcoal/75 sm:text-lg"
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9, delay: 0.55, ease }}
        >
          Describe a mood, clone a favorite, or build a fragrance from scratch. AUREL turns your idea into a
          personalized scent profile.
        </motion.p>

        <motion.div
          className="mt-10 flex flex-col gap-3 sm:flex-row"
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9, delay: 0.7, ease }}
        >
          <Button href="/ai-perfume" size="lg" icon={<ArrowRight className="h-4 w-4" />} className="w-full sm:w-auto">
            Create with AI
          </Button>
          <Button href="/clone" size="lg" variant="secondary" className="w-full sm:w-auto">
            Clone a Perfume
          </Button>
        </motion.div>

        <motion.dl
          className="mt-14 grid max-w-md grid-cols-3 gap-6 border-t border-line pt-6"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 1 }}
        >
          {[
            ["120+", "Raw materials"],
            ["3 min", "Idea to profile"],
            ["50 ml", "Blended to order"],
          ].map(([value, label]) => (
            <div key={label}>
              <dt className="sr-only">{label}</dt>
              <dd className="font-serif text-2xl text-ink sm:text-3xl">{value}</dd>
              <dd className="mt-1 text-[0.68rem] uppercase tracking-[0.16em] text-stone">{label}</dd>
            </div>
          ))}
        </motion.dl>
      </div>

      {/* Visual */}
      <motion.div
        className="relative order-1 mx-auto flex w-full max-w-[460px] items-end justify-center lg:order-2"
        initial={{ opacity: 0, scale: 0.96 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 1.4, ease }}
      >
        {/* Arch */}
        <div className="absolute inset-x-[8%] bottom-0 top-[4%] rounded-t-full border border-line bg-gradient-to-b from-white/80 via-cream to-sand/80 shadow-[inset_0_1px_0_white]" />
        <div className="absolute inset-x-[14%] bottom-[6%] top-[10%] rounded-t-full border border-champagne/25" />
        {/* glow */}
        <div className="absolute bottom-[18%] left-1/2 h-56 w-56 -translate-x-1/2 rounded-full bg-[#5B3A2A]/20 blur-3xl" />

        <div className="relative z-10 flex aspect-[4/5] w-full items-end justify-center pb-[10%]">
          <div className="hidden sm:block">
            <PerfumeBottle name="Noir Éclat" color="#5B3A2A" size="xl" />
          </div>
          <div className="sm:hidden">
            <PerfumeBottle name="Noir Éclat" color="#5B3A2A" size="lg" />
          </div>
        </div>

        {FLOATING_NOTES.map((n) => (
          <motion.div
            key={n.label}
            className={`absolute z-20 ${n.className}`}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: n.delay, ease }}
          >
            <motion.div
              animate={{ y: [0, -6, 0] }}
              transition={{ duration: 5 + n.delay, repeat: Infinity, ease: "easeInOut" }}
              className="flex items-center gap-2.5 rounded-full border border-white bg-white/75 py-2 pl-2 pr-4 shadow-soft backdrop-blur-md"
            >
              <span className="h-6 w-6 rounded-full" style={{ background: `radial-gradient(circle at 30% 30%, #fff, ${n.color})` }} />
              <span className="leading-tight">
                <span className="block text-[0.55rem] font-semibold uppercase tracking-[0.2em] text-stone">{n.tier}</span>
                <span className="block font-serif text-base text-ink">{n.label}</span>
              </span>
            </motion.div>
          </motion.div>
        ))}

        <motion.div
          className="absolute -bottom-5 right-[4%] z-20 flex items-center gap-3 rounded-2xl border border-white bg-ink/90 px-4 py-3 text-ivory shadow-lift backdrop-blur"
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 1.4, ease }}
        >
          <Sparkles className="h-4 w-4 text-champagne" />
          <span className="text-[0.7rem] leading-tight">
            <span className="block uppercase tracking-[0.18em] text-ivory/60">AI confidence</span>
            <span className="font-serif text-lg">91% match</span>
          </span>
        </motion.div>
      </motion.div>
    </section>
  );
}
