"use client";

/**
 * Client-side "studio" state shared across pages:
 *  - the fragrance currently being customised (draft)
 *  - the user's saved creations and favourites
 *  - a demo cart counter and toast notifications
 *
 * Prototype only: state persists in the browser (localStorage/sessionStorage).
 * In production these would be backed by authenticated API calls, e.g.
 *   POST /api/me/fragrances, POST /api/me/favorites, POST /api/cart
 */
import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from "react";
import type { Creation, Perfume, ScentResult } from "@/lib/types";
import { MOCK_FAVORITE_IDS } from "@/data/collection";
import { uid } from "@/lib/utils";

export interface ToastState {
  id: number;
  message: string;
  detail?: string;
  href?: string;
  hrefLabel?: string;
}

interface StudioContextValue {
  /** True once persisted browser state has been loaded. */
  hydrated: boolean;
  draft: ScentResult | null;
  setDraft: (draft: ScentResult) => void;
  draftFromPerfume: (perfume: Perfume) => ScentResult;

  creations: Creation[];
  saveCreation: (result: ScentResult) => Creation;

  favorites: string[];
  isFavorite: (id: string) => boolean;
  toggleFavorite: (id: string, name?: string) => void;

  cartCount: number;
  addToCart: (name: string) => void;

  toast: ToastState | null;
  notify: (toast: Omit<ToastState, "id">) => void;
  dismissToast: () => void;
}

const StudioContext = createContext<StudioContextValue | null>(null);

const KEYS = {
  draft: "aurel:draft",
  creations: "aurel:creations",
  favorites: "aurel:favorites",
  cart: "aurel:cart",
};

function read<T>(storage: "local" | "session", key: string, fallback: T): T {
  try {
    const store = storage === "local" ? window.localStorage : window.sessionStorage;
    const raw = store.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

function write(storage: "local" | "session", key: string, value: unknown) {
  try {
    const store = storage === "local" ? window.localStorage : window.sessionStorage;
    store.setItem(key, JSON.stringify(value));
  } catch {
    /* storage unavailable (private mode) — state simply won't persist */
  }
}

export function StudioProvider({ children }: { children: React.ReactNode }) {
  const [draft, setDraftState] = useState<ScentResult | null>(null);
  const [creations, setCreations] = useState<Creation[]>([]);
  const [favorites, setFavorites] = useState<string[]>(MOCK_FAVORITE_IDS);
  const [cartCount, setCartCount] = useState(0);
  const [toast, setToast] = useState<ToastState | null>(null);
  const [hydrated, setHydrated] = useState(false);
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Load persisted state after mount (avoids SSR hydration mismatches).
  useEffect(() => {
    setDraftState(read<ScentResult | null>("session", KEYS.draft, null));
    setCreations(read<Creation[]>("local", KEYS.creations, []));
    setFavorites(read<string[]>("local", KEYS.favorites, MOCK_FAVORITE_IDS));
    setCartCount(read<number>("local", KEYS.cart, 0));
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    write("local", KEYS.creations, creations);
    write("local", KEYS.favorites, favorites);
    write("local", KEYS.cart, cartCount);
  }, [hydrated, creations, favorites, cartCount]);

  const setDraft = useCallback((next: ScentResult) => {
    setDraftState(next);
    write("session", KEYS.draft, next);
  }, []);

  const draftFromPerfume = useCallback(
    (perfume: Perfume): ScentResult => ({ ...perfume, confidence: 100, source: "catalog" }),
    [],
  );

  const dismissToast = useCallback(() => {
    if (toastTimer.current) clearTimeout(toastTimer.current);
    setToast(null);
  }, []);

  const notify = useCallback((next: Omit<ToastState, "id">) => {
    if (toastTimer.current) clearTimeout(toastTimer.current);
    setToast({ ...next, id: Date.now() });
    toastTimer.current = setTimeout(() => setToast(null), 4200);
  }, []);

  const saveCreation = useCallback((result: ScentResult): Creation => {
    const creation: Creation = {
      ...result,
      id: uid("mine"),
      source: result.source === "catalog" ? "custom" : result.source,
      createdAt: new Date().toISOString(),
    };
    // TODO(api): POST /api/me/fragrances
    setCreations((prev) => [creation, ...prev]);
    return creation;
  }, []);

  const isFavorite = useCallback((id: string) => favorites.includes(id), [favorites]);

  const toggleFavorite = useCallback(
    (id: string, name?: string) => {
      const adding = !favorites.includes(id);
      // TODO(api): POST/DELETE /api/me/favorites/:id
      setFavorites((prev) => (adding ? [...prev, id] : prev.filter((f) => f !== id)));
      if (name) {
        notify({
          message: adding ? `${name} added to favorites` : `${name} removed from favorites`,
          href: adding ? "/my-fragrances" : undefined,
          hrefLabel: adding ? "View" : undefined,
        });
      }
    },
    [favorites, notify],
  );

  const addToCart = useCallback(
    (name: string) => {
      // TODO(api): POST /api/cart — demo only, no checkout in the prototype.
      setCartCount((c) => c + 1);
      notify({ message: `${name} added to your bag`, detail: "Demo mode — checkout is not enabled." });
    },
    [notify],
  );

  const value = useMemo<StudioContextValue>(
    () => ({
      hydrated,
      draft,
      setDraft,
      draftFromPerfume,
      creations,
      saveCreation,
      favorites,
      isFavorite,
      toggleFavorite,
      cartCount,
      addToCart,
      toast,
      notify,
      dismissToast,
    }),
    [hydrated, draft, setDraft, draftFromPerfume, creations, saveCreation, favorites, isFavorite, toggleFavorite, cartCount, addToCart, toast, notify, dismissToast],
  );

  return <StudioContext.Provider value={value}>{children}</StudioContext.Provider>;
}

export function useStudio(): StudioContextValue {
  const ctx = useContext(StudioContext);
  if (!ctx) throw new Error("useStudio must be used inside <StudioProvider>");
  return ctx;
}
