import { Button } from "@/components/Button";
import { PerfumeBottle } from "@/components/PerfumeBottle";

export default function NotFound() {
  return (
    <section className="container-luxe flex min-h-[70vh] flex-col items-center justify-center py-20 text-center">
      <PerfumeBottle name="404" color="#C9A96E" size="md" subtitle="Lost trail" />
      <p className="eyebrow mt-10">Page not found</p>
      <h1 className="display mt-4 text-5xl sm:text-6xl">This scent has faded.</h1>
      <p className="mt-4 max-w-md text-charcoal/70">The page you were looking for doesn&apos;t exist. Let&apos;s find you something new.</p>
      <div className="mt-8">
        <Button href="/">Return home</Button>
      </div>
    </section>
  );
}
