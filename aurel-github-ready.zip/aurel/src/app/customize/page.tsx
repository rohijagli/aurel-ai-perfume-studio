"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowLeft, Bookmark, Check, RotateCcw, ShoppingBag, Sparkles } from "lucide-react";
import { PerfumeBottle } from "@/components/PerfumeBottle";
import { NoteSelector } from "@/components/NoteSelector";
import { ScentSlider } from "@/components/ScentSlider";
import { Button } from "@/components/Button";
import { RevealLines } from "@/components/Reveal";
import { useStudio } from "@/context/StudioContext";
import { getPerfumeById } from "@/data/perfumes";
import { MAX_SELECTED_NOTES, isLibraryNote, tierOf } from "@/data/notes";
import { DIMENSIONS, dominantLabel, hexToRgba, intensityLabel, profileToColor } from "@/lib/scent";
import type { NoteTier, ScentProfile, ScentResult } from "@/lib/types";
import { cn, formatPrice } from "@/lib/utils";

const CONCENTRATIONS = [
  { id: "edp", label: "Eau de Parfum", short: "EDP · 18%", factor: 1 },
  { id: "extrait", label: "Extrait de Parfum", short: "Extrait · 25%", factor: 1.35 },
] as const;

const SIZES = [
  { ml: 50, factor: 1 },
  { ml: 100, factor: 1.7 },
] as const;

const TIERS: { key: NoteTier; label: string }[] = [
  { key: "top", label: "Top" },
  { key: "heart", label: "Heart" },
  { key: "base", label: "Base" },
];

function fallbackDraft(): ScentResult {
  const noir = getPerfumeById("noir-eclat")!;
  return { ...noir, confidence: 91, source: "ai" };
}

function initialNotes(d: ScentResult): string[] {
  return [...d.topNotes, ...d.heartNotes, ...d.baseNotes].filter(isLibraryNote).slice(0, MAX_SELECTED_NOTES);
}

const SOURCE_LABEL: Record<ScentResult["source"], string> = {
  ai: "From your AI generation",
  clone: "From your clone analysis",
  custom: "From your collection",
  catalog: "From the AUREL collection",
};

export default function CustomizePage() {
  const { draft, hydrated, saveCreation, addToCart, notify } = useStudio();
  const base = useMemo(() => draft ?? fallbackDraft(), [draft]);

  const [name, setName] = useState(base.name);
  const [notes, setNotes] = useState<string[]>(() => initialNotes(base));
  const [profile, setProfile] = useState<ScentProfile>(base.profile);
  const [concentration, setConcentration] = useState<(typeof CONCENTRATIONS)[number]["id"]>("edp");
  const [size, setSize] = useState<number>(50);
  const [savedId, setSavedId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Load the draft once persisted state is available (or when a new draft arrives).
  useEffect(() => {
    if (!hydrated) return;
    setName(base.name);
    setNotes(initialNotes(base));
    setProfile(base.profile);
    setSavedId(null);
    setError(null);
  }, [hydrated, base]);

  const color = useMemo(() => profileToColor(profile, base.color), [profile, base.color]);
  const character = dominantLabel(profile);
  const intensity = intensityLabel(profile);
  const conc = CONCENTRATIONS.find((c) => c.id === concentration)!;
  const sizeFactor = SIZES.find((s) => s.ml === size)!.factor;
  const price = Math.round((base.price * conc.factor * sizeFactor) / 100) * 100;
  const displayName = name.trim() || "Untitled";

  const notesByTier = (tier: NoteTier) => notes.filter((n) => tierOf(n) === tier);

  const markDirty = () => setSavedId(null);

  const buildResult = (): ScentResult => ({
    ...base,
    name: displayName,
    topNotes: notesByTier("top"),
    heartNotes: notesByTier("heart"),
    baseNotes: notesByTier("base"),
    profile,
    color,
    price,
    family: base.family,
    source: base.source === "catalog" ? "custom" : base.source,
  });

  const validate = () => {
    if (!name.trim()) return "Give your fragrance a name before saving.";
    if (notes.length < 3) return "Select at least 3 notes to complete your pyramid.";
    return null;
  };

  const handleSave = () => {
    const problem = validate();
    setError(problem);
    if (problem) return;
    // TODO(api): POST /api/me/fragrances
    const created = saveCreation(buildResult());
    setSavedId(created.id);
    notify({ message: `${displayName} saved to My Fragrances`, href: "/my-fragrances", hrefLabel: "View" });
  };

  const handleCart = () => {
    const problem = validate();
    setError(problem);
    if (problem) return;
    addToCart(displayName);
  };

  const handleReset = () => {
    setName(base.name);
    setNotes(initialNotes(base));
    setProfile(base.profile);
    setConcentration("edp");
    setSize(50);
    setError(null);
    setSavedId(null);
  };

  return (
    <div className="container-luxe">
      <div className="flex flex-col gap-4 pb-8 pt-10 sm:pt-14">
        <Link
          href={base.source === "clone" ? "/clone" : base.source === "catalog" ? "/explore" : "/ai-perfume"}
          className="inline-flex w-fit items-center gap-2 text-xs font-medium uppercase tracking-[0.16em] text-stone transition-colors hover:text-ink"
        >
          <ArrowLeft className="h-3.5 w-3.5" /> Back
        </Link>
        <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
          <div>
            <p className="eyebrow">Customize · {SOURCE_LABEL[base.source]}</p>
            <h1 className="display mt-4 text-[3.2rem] sm:text-7xl">
              <RevealLines animateOnMount lines={["Make it yours."]} />
            </h1>
          </div>
          {base.reference && (
            <p className="text-sm text-stone">
              Inspired by <span className="font-serif text-lg italic text-ink">{base.reference}</span>
            </p>
          )}
        </div>
      </div>

      <div className="grid gap-8 lg:grid-cols-[0.85fr_1.15fr] lg:gap-10">
        {/* ---------------- Preview ---------------- */}
        <aside className="lg:sticky lg:top-28 lg:self-start">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
            className="overflow-hidden rounded-[2rem] border border-line/80 bg-white shadow-soft"
          >
            <div
              className="relative flex flex-col items-center px-6 pb-8 pt-12 transition-[background] duration-700"
              style={{
                background: `radial-gradient(60% 55% at 50% 55%, ${hexToRgba(color, 0.4)} 0%, transparent 70%), linear-gradient(180deg, #fbf8f3, #f1eadf)`,
              }}
            >
              <span className="absolute left-5 top-5 inline-flex items-center gap-1.5 rounded-full bg-white/70 px-3 py-1 text-[0.6rem] font-semibold uppercase tracking-[0.2em] text-charcoal backdrop-blur">
                <Sparkles className="h-3 w-3 text-gold" /> Live preview
              </span>
              <span className="absolute right-5 top-5 rounded-full bg-white/70 px-3 py-1 text-[0.6rem] font-semibold uppercase tracking-[0.2em] text-charcoal backdrop-blur">
                {size} ml
              </span>
              <div className="hidden sm:block">
                <PerfumeBottle name={displayName} color={color} size="lg" subtitle={conc.label} />
              </div>
              <div className="sm:hidden">
                <PerfumeBottle name={displayName} color={color} size="md" subtitle={conc.label} />
              </div>
              <AnimatePresence mode="wait">
                <motion.p
                  key={character}
                  initial={{ opacity: 0, y: 6 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -6 }}
                  transition={{ duration: 0.3 }}
                  className="mt-6 font-serif text-2xl italic text-ink"
                >
                  {character}
                </motion.p>
              </AnimatePresence>
              <p className="mt-1 text-xs uppercase tracking-[0.18em] text-stone">{intensity}</p>
            </div>

            {/* Pyramid summary */}
            <div className="grid grid-cols-3 divide-x divide-line border-t border-line">
              {TIERS.map((t) => {
                const list = notesByTier(t.key);
                return (
                  <div key={t.key} className="min-h-[112px] px-3 py-4 sm:px-4">
                    <p className="text-[0.6rem] font-semibold uppercase tracking-[0.22em] text-gold">{t.label}</p>
                    <ul className="mt-2 space-y-0.5">
                      <AnimatePresence initial={false}>
                        {list.map((n) => (
                          <motion.li
                            key={n}
                            initial={{ opacity: 0, x: -6 }}
                            animate={{ opacity: 1, x: 0 }}
                            exit={{ opacity: 0, x: 6 }}
                            transition={{ duration: 0.25 }}
                            className="font-serif text-[1.05rem] leading-snug text-ink"
                          >
                            {n}
                          </motion.li>
                        ))}
                      </AnimatePresence>
                      {list.length === 0 && <li className="text-xs italic text-stone/70">None selected</li>}
                    </ul>
                  </div>
                );
              })}
            </div>

            {/* Signature bars */}
            <div className="border-t border-line px-6 py-5">
              <p className="mb-3 text-[0.6rem] font-semibold uppercase tracking-[0.22em] text-stone">Scent signature</p>
              <div className="flex h-16 items-end gap-2">
                {DIMENSIONS.map((d) => (
                  <div key={d.key} className="flex flex-1 flex-col items-center gap-1.5">
                    <div className="flex h-12 w-full items-end overflow-hidden rounded-md bg-cream">
                      <motion.div
                        className="w-full rounded-md"
                        style={{ backgroundColor: d.color }}
                        animate={{ height: `${Math.max(4, profile[d.key])}%` }}
                        transition={{ type: "spring", stiffness: 200, damping: 26 }}
                      />
                    </div>
                    <span className="text-[0.55rem] uppercase tracking-[0.08em] text-stone">{d.label.slice(0, 5)}</span>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        </aside>

        {/* ---------------- Controls ---------------- */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9, delay: 0.15, ease: [0.22, 1, 0.36, 1] }}
          className="space-y-5"
        >
          {/* Name */}
          <section className="rounded-[2rem] border border-line/80 bg-white p-6 shadow-soft sm:p-8">
            <label htmlFor="perfume-name" className="eyebrow">
              Perfume name
            </label>
            <input
              id="perfume-name"
              value={name}
              maxLength={24}
              onChange={(e) => {
                setName(e.target.value);
                markDirty();
              }}
              placeholder="NOIR ÉCLAT"
              className="mt-3 w-full border-b border-line bg-transparent pb-3 font-serif text-4xl uppercase tracking-[0.06em] text-ink placeholder:text-stone/40 focus:border-champagne focus:outline-none sm:text-5xl"
            />
            <p className="mt-3 text-xs text-stone">
              {base.family} · up to 24 characters, engraved on the label.
            </p>
          </section>

          {/* Notes */}
          <section className="rounded-[2rem] border border-line/80 bg-white p-6 shadow-soft sm:p-8">
            <NoteSelector
              selected={notes}
              onChange={(next) => {
                setNotes(next);
                markDirty();
              }}
            />
          </section>

          {/* Sliders */}
          <section className="rounded-[2rem] border border-line/80 bg-white p-6 shadow-soft sm:p-8">
            <div className="mb-6 flex items-end justify-between">
              <div>
                <p className="eyebrow">Scent dimensions</p>
                <p className="mt-2 text-sm text-stone">Tune the character — watch the juice change colour.</p>
              </div>
            </div>
            <div className="grid gap-x-10 gap-y-7 sm:grid-cols-2">
              {DIMENSIONS.map((d) => (
                <ScentSlider
                  key={d.key}
                  label={d.label}
                  value={profile[d.key]}
                  color={d.color}
                  low={d.low}
                  high={d.high}
                  onChange={(v) => {
                    setProfile((p) => ({ ...p, [d.key]: v }));
                    markDirty();
                  }}
                />
              ))}
            </div>
          </section>

          {/* Format */}
          <section className="rounded-[2rem] border border-line/80 bg-white p-6 shadow-soft sm:p-8">
            <p className="eyebrow">Format</p>
            <div className="mt-5 grid gap-3 sm:grid-cols-2">
              {CONCENTRATIONS.map((c) => (
                <button
                  key={c.id}
                  type="button"
                  onClick={() => setConcentration(c.id)}
                  aria-pressed={concentration === c.id}
                  className={cn(
                    "rounded-2xl border px-5 py-4 text-left transition-all duration-300",
                    concentration === c.id ? "border-ink bg-ink text-ivory" : "border-line hover:border-champagne",
                  )}
                >
                  <span className="block font-serif text-xl">{c.label}</span>
                  <span className={cn("text-xs", concentration === c.id ? "text-ivory/60" : "text-stone")}>{c.short}</span>
                </button>
              ))}
            </div>
            <div className="mt-3 flex gap-3">
              {SIZES.map((s) => (
                <button
                  key={s.ml}
                  type="button"
                  onClick={() => setSize(s.ml)}
                  aria-pressed={size === s.ml}
                  className={cn(
                    "flex-1 rounded-full border py-3 text-sm font-medium transition-all duration-300",
                    size === s.ml ? "border-ink bg-ink text-ivory" : "border-line text-charcoal hover:border-champagne",
                  )}
                >
                  {s.ml} ml
                </button>
              ))}
            </div>
          </section>

          {/* Actions */}
          <section className="rounded-[2rem] bg-ink p-6 text-ivory shadow-lift sm:p-8">
            <div className="flex flex-col justify-between gap-6 sm:flex-row sm:items-center">
              <div>
                <p className="text-[0.62rem] font-semibold uppercase tracking-[0.22em] text-ivory/50">Your fragrance</p>
                <p className="mt-1 font-serif text-3xl uppercase tracking-[0.04em]">{displayName}</p>
                <p className="mt-1 text-sm text-ivory/60">
                  {conc.label} · {size} ml · <span className="text-champagne">{formatPrice(price)}</span>
                </p>
              </div>
              <button
                type="button"
                onClick={handleReset}
                className="inline-flex items-center gap-2 self-start text-xs uppercase tracking-[0.16em] text-ivory/60 transition-colors hover:text-ivory sm:self-center"
              >
                <RotateCcw className="h-3.5 w-3.5" /> Reset
              </button>
            </div>

            <AnimatePresence>
              {error && (
                <motion.p
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  className="mt-4 overflow-hidden text-sm text-champagne"
                  role="alert"
                >
                  {error}
                </motion.p>
              )}
            </AnimatePresence>

            <div className="mt-6 grid gap-3 sm:grid-cols-2">
              <Button
                variant="gold"
                size="lg"
                onClick={handleSave}
                iconLeft={
                  savedId ? <Check className="h-4 w-4" strokeWidth={2.2} /> : <Bookmark className="h-4 w-4" strokeWidth={1.6} />
                }
                className="w-full"
              >
                {savedId ? "Saved" : "Save"}
              </Button>
              <Button
                variant="outlineLight"
                size="lg"
                onClick={handleCart}
                iconLeft={<ShoppingBag className="h-4 w-4" strokeWidth={1.6} />}
                className="w-full"
              >
                Add to Cart
              </Button>
            </div>
            <AnimatePresence>
              {savedId && (
                <motion.p
                  initial={{ opacity: 0, y: 6 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0 }}
                  className="mt-4 text-center text-sm text-ivory/70"
                >
                  Saved to your collection ·{" "}
                  <Link href="/my-fragrances" className="text-champagne underline underline-offset-4">
                    View My Fragrances
                  </Link>
                </motion.p>
              )}
            </AnimatePresence>
          </section>
        </motion.div>
      </div>
    </div>
  );
}
