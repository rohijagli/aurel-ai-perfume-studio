"use client";

import { useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowRight, Copy, Heart, Sparkles } from "lucide-react";
import { PageHeader } from "@/components/PageHeader";
import { PerfumeCard } from "@/components/PerfumeCard";
import { Button } from "@/components/Button";
import { useStudio } from "@/context/StudioContext";
import { BASE_STATS, MOCK_COLLECTION } from "@/data/collection";
import { PERFUMES } from "@/data/perfumes";
import type { Creation, Perfume } from "@/lib/types";
import { useCustomize } from "@/lib/useCustomize";
import { cn, formatDate, pad2 } from "@/lib/utils";

type Tab = "ai" | "clone" | "favorites";

const TABS: { id: Tab; label: string; icon: React.ReactNode }[] = [
  { id: "ai", label: "AI Creations", icon: <Sparkles className="h-3.5 w-3.5" /> },
  { id: "clone", label: "Cloned Perfumes", icon: <Copy className="h-3.5 w-3.5" /> },
  { id: "favorites", label: "Favorites", icon: <Heart className="h-3.5 w-3.5" /> },
];

const BADGES: Record<Creation["source"], string> = {
  ai: "AI Creation",
  clone: "Clone",
  custom: "Custom",
  catalog: "Collection",
};

function metaFor(item: Perfume | Creation): string {
  if ("createdAt" in item) {
    const prefix = item.source === "clone" && item.reference ? `Inspired by ${item.reference}` : item.family;
    return `${prefix} · ${formatDate(item.createdAt)}`;
  }
  return item.family;
}

function EmptyState({ tab }: { tab: Tab }) {
  const copy = {
    ai: { title: "No AI creations yet", text: "Describe a feeling and let AUREL compose it.", href: "/ai-perfume", cta: "Create with AI" },
    clone: { title: "No clones yet", text: "Start from a perfume you already love.", href: "/clone", cta: "Clone a perfume" },
    favorites: { title: "No favorites yet", text: "Tap the heart on any fragrance to keep it here.", href: "/explore", cta: "Explore" },
  }[tab];
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex flex-col items-center rounded-[2rem] border border-dashed border-line px-6 py-16 text-center"
    >
      <p className="font-serif text-3xl text-ink">{copy.title}</p>
      <p className="mt-2 text-stone">{copy.text}</p>
      <div className="mt-6">
        <Button href={copy.href} variant="secondary" icon={<ArrowRight className="h-4 w-4" />}>
          {copy.cta}
        </Button>
      </div>
    </motion.div>
  );
}

export default function MyFragrancesPage() {
  const { creations, favorites } = useStudio();
  const customize = useCustomize();
  const [tab, setTab] = useState<Tab>("ai");

  // Newly saved creations (this session) appear before the mock history.
  const all: Creation[] = useMemo(() => [...creations, ...MOCK_COLLECTION], [creations]);

  const stats = [
    { label: "Created", value: BASE_STATS.created + creations.length, note: "AI, clones & custom" },
    { label: "Saved", value: BASE_STATS.saved + creations.length, note: "In your collection" },
    { label: "Favorites", value: favorites.length, note: "Marked with a heart" },
  ];

  const recent = all.slice(0, 3);

  const tabItems: Array<Perfume | Creation> = useMemo(() => {
    if (tab === "favorites") {
      const pool: Array<Perfume | Creation> = [...all, ...PERFUMES];
      return favorites.map((id) => pool.find((p) => p.id === id)).filter((p): p is Perfume | Creation => Boolean(p));
    }
    if (tab === "clone") return all.filter((c) => c.source === "clone");
    return all.filter((c) => c.source === "ai" || c.source === "custom");
  }, [tab, all, favorites]);

  return (
    <div className="container-luxe">
      <PageHeader
        eyebrow="Your Atelier"
        lines={["My Fragrances"]}
        intro="Everything you've imagined, cloned and kept — ready to revisit, refine or reorder."
      />

      {/* Stats */}
      <div className="grid gap-4 sm:grid-cols-3">
        {stats.map((s, i) => (
          <motion.div
            key={s.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.3 + i * 0.1, ease: [0.22, 1, 0.36, 1] }}
            className="relative overflow-hidden rounded-[1.75rem] border border-line/80 bg-white p-7 shadow-soft"
          >
            <span className="absolute -right-10 -top-10 h-32 w-32 rounded-full bg-champagne/10 blur-2xl" />
            <p className="eyebrow">{s.label}</p>
            <p className="mt-4 font-serif text-7xl leading-none text-ink tabular-nums">{pad2(s.value)}</p>
            <p className="mt-3 text-xs text-stone">{s.note}</p>
          </motion.div>
        ))}
      </div>

      {/* Recent creations */}
      <section className="mt-20">
        <div className="mb-8 flex items-end justify-between gap-4">
          <div>
            <p className="eyebrow">Latest</p>
            <h2 className="display mt-3 text-4xl sm:text-5xl">Recent Creations</h2>
          </div>
          <Button href="/ai-perfume" variant="secondary" size="sm" icon={<ArrowRight className="h-3.5 w-3.5" />}>
            New creation
          </Button>
        </div>
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {recent.map((c, i) => (
            <PerfumeCard
              key={c.id}
              perfume={c}
              onCustomize={() => customize(c)}
              badge={BADGES[c.source]}
              meta={metaFor(c)}
              index={i}
            />
          ))}
        </div>
      </section>

      {/* Library tabs */}
      <section className="mt-20">
        <div className="mb-8 flex flex-col justify-between gap-6 border-b border-line sm:flex-row sm:items-end">
          <div className="pb-0 sm:pb-5">
            <p className="eyebrow">Library</p>
            <h2 className="display mt-3 text-4xl sm:text-5xl">Your collection</h2>
          </div>
          <div className="no-scrollbar -mb-px flex gap-6 overflow-x-auto" role="tablist" aria-label="Collection sections">
            {TABS.map((t) => {
              const active = tab === t.id;
              return (
                <button
                  key={t.id}
                  type="button"
                  role="tab"
                  aria-selected={active}
                  onClick={() => setTab(t.id)}
                  className={cn(
                    "relative flex shrink-0 items-center gap-2 pb-4 text-sm font-medium transition-colors",
                    active ? "text-ink" : "text-stone hover:text-ink",
                  )}
                >
                  {t.icon}
                  {t.label}
                  {active && (
                    <motion.span layoutId="collection-tab" className="absolute inset-x-0 -bottom-px h-0.5 bg-champagne" />
                  )}
                </button>
              );
            })}
          </div>
        </div>

        <AnimatePresence mode="wait">
          <motion.div
            key={tab}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.4 }}
            role="tabpanel"
          >
            {tabItems.length === 0 ? (
              <EmptyState tab={tab} />
            ) : (
              <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
                {tabItems.map((item, i) => (
                  <PerfumeCard
                    key={item.id}
                    perfume={item}
                    onCustomize={() => customize(item)}
                    badge={"source" in item ? BADGES[(item as Creation).source] : "Collection"}
                    meta={metaFor(item)}
                    index={i}
                  />
                ))}
              </div>
            )}
          </motion.div>
        </AnimatePresence>
      </section>
    </div>
  );
}
