"use client";

import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Sparkles, WandSparkles } from "lucide-react";
import { PageHeader } from "@/components/PageHeader";
import { Button } from "@/components/Button";
import { AIResult } from "@/components/AIResult";
import { LoadingSequence, useStepSequence } from "@/components/LoadingSequence";
import { GENERATE_STEPS, generatePerfume } from "@/lib/mockAI";
import type { ScentResult } from "@/lib/types";
import { useCustomize } from "@/lib/useCustomize";
import { useStudio } from "@/context/StudioContext";
import { cn } from "@/lib/utils";

const SUGGESTIONS = [
  "Fresh and clean",
  "Romantic floral",
  "Dark and mysterious",
  "Warm and luxurious",
  "Beachy and refreshing",
];

const EXAMPLE_PROMPT = "Warm, luxurious and mysterious for winter evenings.";
const MAX_LENGTH = 280;

type Phase = "idle" | "loading" | "done";

export default function AIPerfumePage() {
  const [prompt, setPrompt] = useState("");
  const [phase, setPhase] = useState<Phase>("idle");
  const [result, setResult] = useState<ScentResult | null>(null);
  const { step, run } = useStepSequence(GENERATE_STEPS.length);
  const customize = useCustomize();
  const { saveCreation, notify } = useStudio();
  const resultRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    if (phase !== "idle") resultRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
  }, [phase]);

  const canGenerate = prompt.trim().length >= 3 && phase !== "loading";

  const handleGenerate = async () => {
    if (!canGenerate) return;
    setResult(null);
    setPhase("loading");
    // TODO(api): generatePerfume() is mocked — see src/lib/mockAI.ts
    const generated = await run(() => generatePerfume(prompt));
    setResult(generated);
    setPhase("done");
  };

  const handleChip = (chip: string) => {
    setPrompt((current) => {
      const trimmed = current.trim();
      if (!trimmed) return chip;
      if (trimmed.toLowerCase().includes(chip.toLowerCase())) return current;
      return `${trimmed.replace(/[.]$/, "")}, ${chip.toLowerCase()}`;
    });
    textareaRef.current?.focus();
  };

  const handleReset = () => {
    setPhase("idle");
    setResult(null);
    window.scrollTo({ top: 0, behavior: "smooth" });
    setTimeout(() => textareaRef.current?.focus(), 400);
  };

  return (
    <div className="container-luxe">
      <PageHeader
        eyebrow="AI Perfume Generator"
        lines={["Describe a feeling.", <em key="l2" className="text-gold">We&apos;ll make the scent.</em>]}
        intro="Write it the way you'd describe it to a friend — a season, a place, a memory, a mood. Our model composes a complete fragrance profile."
      />

      {/* Composer */}
      <motion.form
        onSubmit={(e) => {
          e.preventDefault();
          handleGenerate();
        }}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.9, delay: 0.3, ease: [0.22, 1, 0.36, 1] }}
        className="rounded-[2rem] border border-line/80 bg-white p-5 shadow-soft sm:p-8"
      >
        <label htmlFor="prompt" className="flex items-center justify-between gap-4 px-1">
          <span className="font-serif text-2xl text-ink sm:text-[1.75rem]">What should your perfume feel like?</span>
          <Sparkles className="hidden h-5 w-5 shrink-0 text-champagne sm:block" strokeWidth={1.4} />
        </label>

        <div className="relative mt-5">
          <textarea
            id="prompt"
            ref={textareaRef}
            value={prompt}
            maxLength={MAX_LENGTH}
            disabled={phase === "loading"}
            onChange={(e) => setPrompt(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) handleGenerate();
            }}
            placeholder={`e.g. “${EXAMPLE_PROMPT}”`}
            rows={4}
            className="w-full resize-none rounded-[1.5rem] border border-line bg-ivory/60 px-6 py-5 font-serif text-[1.45rem] leading-snug text-ink placeholder:italic placeholder:text-stone/60 transition-colors focus:border-champagne focus:bg-white focus:outline-none disabled:opacity-60 sm:text-[1.65rem]"
          />
          <span className="pointer-events-none absolute bottom-4 right-5 text-[0.68rem] tabular-nums text-stone/70">
            {prompt.length}/{MAX_LENGTH}
          </span>
        </div>

        <div className="mt-5 flex flex-wrap gap-2" role="group" aria-label="Prompt suggestions">
          {SUGGESTIONS.map((chip) => {
            const active = prompt.toLowerCase().includes(chip.toLowerCase());
            return (
              <motion.button
                key={chip}
                type="button"
                disabled={phase === "loading"}
                onClick={() => handleChip(chip)}
                whileHover={{ y: -2 }}
                whileTap={{ scale: 0.97 }}
                className={cn(
                  "rounded-full border px-4 py-2 text-[0.78rem] transition-colors duration-300 disabled:opacity-50",
                  active
                    ? "border-champagne bg-champagne/15 text-ink"
                    : "border-line bg-white text-charcoal hover:border-champagne/70",
                )}
              >
                {chip}
              </motion.button>
            );
          })}
        </div>

        <div className="mt-8 flex flex-col-reverse items-stretch gap-4 border-t border-line pt-6 sm:flex-row sm:items-center sm:justify-between">
          <button
            type="button"
            disabled={phase === "loading"}
            onClick={() => setPrompt(EXAMPLE_PROMPT)}
            className="text-left text-xs text-stone underline decoration-line underline-offset-4 transition-colors hover:text-ink disabled:opacity-50"
          >
            Try the example: “{EXAMPLE_PROMPT}”
          </button>
          <Button
            type="submit"
            size="lg"
            disabled={!canGenerate}
            iconLeft={<WandSparkles className="h-4 w-4" strokeWidth={1.6} />}
            className="w-full sm:w-auto"
          >
            {phase === "loading" ? "Composing…" : "Generate My Perfume"}
          </Button>
        </div>
      </motion.form>

      {/* Output */}
      <div ref={resultRef} className="scroll-mt-28 pt-10">
        <AnimatePresence mode="wait">
          {phase === "loading" && <LoadingSequence key="loading" steps={GENERATE_STEPS} step={step} />}
          {phase === "done" && result && (
            <AIResult
              key={result.id}
              result={result}
              mode="generate"
              onCustomize={() => customize(result)}
              onSave={() => {
                saveCreation(result);
                notify({ message: `${result.name} saved to your collection`, href: "/my-fragrances", hrefLabel: "View" });
              }}
              onReset={handleReset}
            />
          )}
          {phase === "idle" && (
            <motion.div
              key="empty"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="grid gap-4 sm:grid-cols-3"
            >
              {[
                ["Be sensory", "Mention textures, temperatures, colours — “velvety”, “sun-warmed”, “icy”."],
                ["Set the scene", "A season, a time of day, a place. “Winter evenings in a jazz bar.”"],
                ["Name the feeling", "Confident, nostalgic, serene, magnetic — the mood shapes the family."],
              ].map(([title, text], i) => (
                <motion.div
                  key={title}
                  initial={{ opacity: 0, y: 16 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.5 + i * 0.1, duration: 0.7 }}
                  className="rounded-[1.5rem] border border-line/70 bg-white/50 p-6"
                >
                  <p className="font-serif text-lg text-champagne">0{i + 1}</p>
                  <p className="mt-3 font-serif text-2xl text-ink">{title}</p>
                  <p className="mt-2 text-sm leading-relaxed text-stone">{text}</p>
                </motion.div>
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
