"use client";

import { useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Search, X } from "lucide-react";
import { PageHeader } from "@/components/PageHeader";
import { PerfumeCard } from "@/components/PerfumeCard";
import { Button } from "@/components/Button";
import { PERFUMES } from "@/data/perfumes";
import type { FragranceCategory, Perfume } from "@/lib/types";
import { useCustomize } from "@/lib/useCustomize";
import { cn } from "@/lib/utils";

const CATEGORIES: Array<"All" | FragranceCategory> = ["All", "Fresh", "Floral", "Woody", "Amber", "Citrus", "Musk"];

/** Client-side filter over the mock catalogue. Future: GET /api/perfumes?q=&category= */
function matches(perfume: Perfume, query: string, category: "All" | FragranceCategory) {
  if (category !== "All" && perfume.category !== category) return false;
  if (!query) return true;
  const haystack = [
    perfume.name,
    perfume.family,
    perfume.category,
    perfume.description,
    perfume.mood ?? "",
    ...perfume.topNotes,
    ...perfume.heartNotes,
    ...perfume.baseNotes,
  ]
    .join(" ")
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .toLowerCase();
  return query
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .toLowerCase()
    .split(/\s+/)
    .filter(Boolean)
    .every((term) => haystack.includes(term));
}

export default function ExplorePage() {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState<"All" | FragranceCategory>("All");
  const customize = useCustomize();

  const results = useMemo(() => PERFUMES.filter((p) => matches(p, query.trim(), category)), [query, category]);

  const counts = useMemo(() => {
    const map: Record<string, number> = { All: PERFUMES.length };
    for (const p of PERFUMES) map[p.category] = (map[p.category] ?? 0) + 1;
    return map;
  }, []);

  const clear = () => {
    setQuery("");
    setCategory("All");
  };

  return (
    <div className="container-luxe">
      <PageHeader
        eyebrow="Explore"
        lines={["Find your next", <em key="l2" className="text-gold">signature.</em>]}
        intro="Every fragrance is a starting point. Choose one you love, then tune its notes and character in the studio."
      />

      {/* Controls */}
      <div className="sticky top-20 z-30 -mx-5 mb-10 border-b border-line/60 bg-ivory/85 px-5 py-4 backdrop-blur-xl sm:-mx-8 sm:px-8 lg:-mx-12 lg:px-12">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div className="relative w-full lg:max-w-sm">
            <Search className="pointer-events-none absolute left-5 top-1/2 h-4 w-4 -translate-y-1/2 text-stone" />
            <label htmlFor="explore-search" className="sr-only">
              Search fragrances
            </label>
            <input
              id="explore-search"
              type="search"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search by name, note or mood"
              className="h-12 w-full rounded-full border border-line bg-white pl-12 pr-11 text-sm text-ink placeholder:text-stone/70 transition-colors focus:border-champagne focus:outline-none [&::-webkit-search-cancel-button]:hidden"
            />
            {query && (
              <button
                type="button"
                onClick={() => setQuery("")}
                aria-label="Clear search"
                className="absolute right-3 top-1/2 flex h-7 w-7 -translate-y-1/2 items-center justify-center rounded-full text-stone hover:bg-ink/5 hover:text-ink"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            )}
          </div>

          <div className="no-scrollbar -mx-5 flex gap-2 overflow-x-auto px-5 lg:mx-0 lg:px-0" role="tablist" aria-label="Fragrance families">
            {CATEGORIES.map((c) => {
              const active = category === c;
              return (
                <button
                  key={c}
                  type="button"
                  role="tab"
                  aria-selected={active}
                  onClick={() => setCategory(c)}
                  className={cn(
                    "relative shrink-0 rounded-full px-4 py-2 text-[0.78rem] font-medium transition-colors duration-300",
                    active ? "text-ivory" : "text-charcoal hover:text-ink",
                  )}
                >
                  {active && (
                    <motion.span
                      layoutId="category-pill"
                      className="absolute inset-0 rounded-full bg-ink"
                      transition={{ type: "spring", stiffness: 400, damping: 34 }}
                    />
                  )}
                  <span className="relative">
                    {c}
                    <span className={cn("ml-1.5 text-[0.65rem]", active ? "text-ivory/60" : "text-stone/70")}>{counts[c] ?? 0}</span>
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      <p className="mb-6 text-sm text-stone" aria-live="polite">
        {results.length} {results.length === 1 ? "fragrance" : "fragrances"}
        {category !== "All" && <> in <span className="text-ink">{category}</span></>}
        {query.trim() && <> matching “<span className="text-ink">{query.trim()}</span>”</>}
      </p>

      <motion.div layout className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        <AnimatePresence>
          {results.map((p, i) => (
            <PerfumeCard key={p.id} perfume={p} onCustomize={customize} index={i} />
          ))}
        </AnimatePresence>
      </motion.div>

      <AnimatePresence>
        {results.length === 0 && (
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="flex flex-col items-center rounded-[2rem] border border-dashed border-line px-6 py-20 text-center"
          >
            <p className="font-serif text-4xl text-ink">Nothing quite like that — yet.</p>
            <p className="mt-3 max-w-md text-stone">
              No fragrance in the collection matches your search. Try another note, or let AI compose it for you.
            </p>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <Button variant="secondary" onClick={clear}>
                Clear filters
              </Button>
              <Button href="/ai-perfume">Create it with AI</Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
