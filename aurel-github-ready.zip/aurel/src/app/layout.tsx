import type { Metadata, Viewport } from "next";
import "./globals.css";
import { StudioProvider } from "@/context/StudioContext";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { Toast } from "@/components/Toast";

export const metadata: Metadata = {
  title: {
    default: "AUREL — AI Perfume Studio",
    template: "%s · AUREL",
  },
  description:
    "Describe a mood, clone a favorite, or build a fragrance from scratch. AUREL turns your idea into a personalized scent profile.",
};

export const viewport: Viewport = {
  themeColor: "#f8f4ed",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        {/* eslint-disable-next-line @next/next/no-page-custom-font -- App Router root layout */}
        <link
          rel="stylesheet"
          href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,400;0,500;0,600;1,400;1,500&family=Manrope:wght@400;500;600;700&display=swap"
        />
      </head>
      <body className="min-h-screen">
        <StudioProvider>
          <Navbar />
          <main className="pt-20">{children}</main>
          <Footer />
          <Toast />
        </StudioProvider>
      </body>
    </html>
  );
}
