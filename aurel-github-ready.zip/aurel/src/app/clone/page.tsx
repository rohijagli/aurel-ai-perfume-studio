"use client";

import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Camera, ScanSearch, Search, Type } from "lucide-react";
import { PageHeader } from "@/components/PageHeader";
import { Button } from "@/components/Button";
import { UploadBox, type UploadSelection } from "@/components/UploadBox";
import { AIResult } from "@/components/AIResult";
import { LoadingSequence, useStepSequence } from "@/components/LoadingSequence";
import { CLONE_STEPS, analyzePerfume, clonePerfume } from "@/lib/mockAI";
import type { ScentResult } from "@/lib/types";
import { useCustomize } from "@/lib/useCustomize";
import { useStudio } from "@/context/StudioContext";

const POPULAR = ["Bleu de Chanel", "Dior Sauvage", "Baccarat Rouge 540", "Creed Aventus", "Black Opium"];

type Phase = "idle" | "loading" | "done";

function OptionCard({
  letter,
  title,
  text,
  icon,
  children,
  delay,
}: {
  letter: string;
  title: string;
  text: string;
  icon: React.ReactNode;
  children: React.ReactNode;
  delay: number;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 24 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.9, delay, ease: [0.22, 1, 0.36, 1] }}
      className="flex flex-col rounded-[2rem] border border-line/80 bg-white p-6 shadow-soft sm:p-8"
    >
      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="eyebrow">Option {letter}</p>
          <h2 className="mt-3 font-serif text-[2rem] leading-tight text-ink">{title}</h2>
          <p className="mt-2 text-sm text-stone">{text}</p>
        </div>
        <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full border border-champagne/50 bg-cream text-gold">
          {icon}
        </span>
      </div>
      <div className="mt-7 flex flex-1 flex-col">{children}</div>
    </motion.div>
  );
}

export default function ClonePage() {
  const [upload, setUpload] = useState<UploadSelection>(null);
  const [name, setName] = useState("");
  const [phase, setPhase] = useState<Phase>("idle");
  const [result, setResult] = useState<ScentResult | null>(null);
  const { step, run } = useStepSequence(CLONE_STEPS.length);
  const customize = useCustomize();
  const { saveCreation, notify } = useStudio();
  const outputRef = useRef<HTMLDivElement>(null);
  const loading = phase === "loading";

  useEffect(() => {
    if (phase !== "idle") outputRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
  }, [phase]);

  const analyse = async (task: () => Promise<ScentResult>) => {
    setResult(null);
    setPhase("loading");
    const r = await run(task);
    setResult(r);
    setPhase("done");
  };

  // TODO(api): both handlers call mocked functions in src/lib/mockAI.ts
  const handleImage = () => {
    if (!upload || loading) return;
    analyse(() => clonePerfume(upload.kind === "file" ? upload.file : null));
  };

  const handleName = (value = name) => {
    if (value.trim().length < 2 || loading) return;
    setName(value);
    analyse(() => analyzePerfume(value));
  };

  const reset = () => {
    setPhase("idle");
    setResult(null);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <div className="container-luxe">
      <PageHeader
        eyebrow="Perfume Cloning"
        lines={["Start with something", <em key="l2" className="text-gold">you already love.</em>]}
        intro="Show us a bottle or name a fragrance. AUREL analyses its family and structure, then composes an interpretation you can make your own."
      />

      <div className="grid gap-5 lg:grid-cols-2">
        <OptionCard
          letter="A"
          title="Upload perfume image"
          text="A photo of the bottle or box is enough."
          icon={<Camera className="h-5 w-5" strokeWidth={1.4} />}
          delay={0.3}
        >
          <UploadBox value={upload} onChange={setUpload} disabled={loading} />
          <div className="mt-auto pt-5">
            <Button
              onClick={handleImage}
              disabled={!upload || loading}
              iconLeft={<ScanSearch className="h-4 w-4" strokeWidth={1.6} />}
              className="w-full"
            >
              Analyze Image
            </Button>
          </div>
        </OptionCard>

        <OptionCard
          letter="B"
          title="Enter perfume name"
          text="Any designer or niche fragrance you know by name."
          icon={<Type className="h-5 w-5" strokeWidth={1.4} />}
          delay={0.4}
        >
          <form
            className="flex flex-1 flex-col"
            onSubmit={(e) => {
              e.preventDefault();
              handleName();
            }}
          >
            <label htmlFor="perfume-name" className="sr-only">
              Perfume name
            </label>
            <div className="relative">
              <Search className="pointer-events-none absolute left-5 top-1/2 h-4 w-4 -translate-y-1/2 text-stone" />
              <input
                id="perfume-name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                disabled={loading}
                placeholder="e.g. Bleu de Chanel"
                autoComplete="off"
                className="h-16 w-full rounded-full border border-line bg-ivory/60 pl-12 pr-5 font-serif text-xl text-ink placeholder:italic placeholder:text-stone/60 transition-colors focus:border-champagne focus:bg-white focus:outline-none disabled:opacity-60"
              />
            </div>

            <p className="mb-3 mt-7 text-[0.65rem] font-semibold uppercase tracking-[0.22em] text-stone">Popular references</p>
            <div className="flex flex-wrap gap-2">
              {POPULAR.map((p) => (
                <motion.button
                  key={p}
                  type="button"
                  disabled={loading}
                  whileHover={{ y: -2 }}
                  whileTap={{ scale: 0.97 }}
                  onClick={() => setName(p)}
                  className="rounded-full border border-line bg-white px-4 py-2 text-[0.78rem] text-charcoal transition-colors hover:border-champagne/70 disabled:opacity-50"
                >
                  {p}
                </motion.button>
              ))}
            </div>

            <div className="mt-auto pt-8">
              <Button
                type="submit"
                disabled={name.trim().length < 2 || loading}
                iconLeft={<ScanSearch className="h-4 w-4" strokeWidth={1.6} />}
                className="w-full"
              >
                Analyze Perfume
              </Button>
            </div>
          </form>
        </OptionCard>
      </div>

      <div ref={outputRef} className="scroll-mt-28 pt-10">
        <AnimatePresence mode="wait">
          {phase === "loading" && <LoadingSequence key="loading" steps={CLONE_STEPS} step={step} />}
          {phase === "done" && result && (
            <AIResult
              key={result.id}
              result={result}
              mode="clone"
              onCustomize={() => customize(result)}
              onSave={() => {
                saveCreation(result);
                notify({ message: `${result.name} saved to your collection`, href: "/my-fragrances", hrefLabel: "View" });
              }}
              onReset={reset}
            />
          )}
        </AnimatePresence>
      </div>

      <p className="mt-10 text-center text-xs text-stone">
        AUREL creates original interpretations inspired by a reference. We do not reproduce or sell third-party
        fragrances.
      </p>
    </div>
  );
}
