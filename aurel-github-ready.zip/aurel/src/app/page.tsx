"use client";

import { motion } from "framer-motion";
import { ArrowRight, Copy, SlidersHorizontal, Sparkles } from "lucide-react";
import { Hero } from "@/components/Hero";
import { FeatureCard } from "@/components/FeatureCard";
import { PerfumeCard } from "@/components/PerfumeCard";
import { Reveal, RevealLines } from "@/components/Reveal";
import { Button } from "@/components/Button";
import { PerfumeBottle } from "@/components/PerfumeBottle";
import { FEATURED_PERFUMES } from "@/data/perfumes";
import { useCustomize } from "@/lib/useCustomize";

const STEPS = [
  {
    n: "01",
    title: "Describe",
    text: "Share a mood, a memory or a moment — “a library on a rainy afternoon”. Or upload a perfume you love.",
  },
  {
    n: "02",
    title: "Discover",
    text: "Our AI translates your words into a fragrance family and a balanced pyramid of top, heart and base notes.",
  },
  {
    n: "03",
    title: "Make it yours",
    text: "Swap notes, tune freshness, sweetness and depth, name your creation — then save it to your collection.",
  },
];

const MARQUEE = ["Bergamot", "Oud", "Iris", "Pink Pepper", "Sandalwood", "Neroli", "Saffron", "Amber", "Jasmine", "Yuzu", "Cedar", "Vanilla"];

export default function HomePage() {
  const customize = useCustomize();

  return (
    <>
      <Hero />

      {/* Notes marquee */}
      <div className="overflow-hidden border-y border-line bg-white/40 py-5" aria-hidden>
        <motion.div
          className="flex w-max gap-12 whitespace-nowrap"
          animate={{ x: ["0%", "-50%"] }}
          transition={{ duration: 40, repeat: Infinity, ease: "linear" }}
        >
          {[...MARQUEE, ...MARQUEE].map((note, i) => (
            <span key={i} className="flex items-center gap-12 font-serif text-2xl italic text-charcoal/60">
              {note}
              <span className="h-1 w-1 rounded-full bg-champagne" />
            </span>
          ))}
        </motion.div>
      </div>

      {/* From a feeling to a bottle */}
      <section className="container-luxe py-24 sm:py-32">
        <div className="grid gap-12 lg:grid-cols-[0.8fr_1.2fr] lg:gap-20">
          <div>
            <Reveal>
              <p className="eyebrow">How it works</p>
            </Reveal>
            <h2 className="display mt-5 text-5xl sm:text-6xl">
              <RevealLines lines={["From a feeling", "to a bottle."]} />
            </h2>
            <Reveal delay={0.2}>
              <p className="mt-6 max-w-sm leading-relaxed text-charcoal/70">
                Perfumery has always started with an emotion. AUREL simply lets you begin there.
              </p>
            </Reveal>
          </div>

          <ol className="divide-y divide-line border-y border-line">
            {STEPS.map((step, i) => (
              <Reveal as="li" key={step.n} delay={i * 0.12} className="group grid gap-4 py-8 sm:grid-cols-[100px_1fr] sm:gap-8 sm:py-10">
                <span className="font-serif text-5xl text-champagne transition-colors duration-500 group-hover:text-gold">
                  {step.n}
                </span>
                <div>
                  <h3 className="font-serif text-3xl text-ink">{step.title}</h3>
                  <p className="mt-3 max-w-lg leading-relaxed text-charcoal/70">{step.text}</p>
                </div>
              </Reveal>
            ))}
          </ol>
        </div>
      </section>

      {/* Feature cards */}
      <section className="container-luxe">
        <div className="grid gap-5 md:grid-cols-3">
          <FeatureCard
            index="I"
            title="Generate"
            text="Tell AI how you want to feel."
            href="/ai-perfume"
            cta="Start generating"
            icon={Sparkles}
          />
          <FeatureCard
            index="II"
            title="Clone"
            text="Start from a perfume you already love."
            href="/clone"
            cta="Clone a perfume"
            icon={Copy}
            delay={0.1}
          />
          <FeatureCard
            index="III"
            title="Customize"
            text="Fine-tune every dimension of your scent."
            href="/customize"
            cta="Open the studio"
            icon={SlidersHorizontal}
            delay={0.2}
          />
        </div>
      </section>

      {/* Featured perfumes */}
      <section className="container-luxe py-24 sm:py-32">
        <div className="mb-12 flex flex-col justify-between gap-6 sm:flex-row sm:items-end">
          <div>
            <Reveal>
              <p className="eyebrow">The Collection</p>
            </Reveal>
            <h2 className="display mt-5 text-5xl sm:text-6xl">
              <RevealLines lines={["Signatures,", "ready to reimagine."]} />
            </h2>
          </div>
          <Reveal delay={0.2}>
            <Button href="/explore" variant="secondary" icon={<ArrowRight className="h-4 w-4" />}>
              Explore all
            </Button>
          </Reveal>
        </div>

        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {FEATURED_PERFUMES.map((perfume, i) => (
            <Reveal key={perfume.id} delay={(i % 3) * 0.08} className="h-full">
              <PerfumeCard perfume={perfume} onCustomize={customize} index={0} />
            </Reveal>
          ))}
        </div>
      </section>

      {/* CTA band */}
      <section className="container-luxe">
        <Reveal>
          <div className="relative overflow-hidden rounded-[2.25rem] bg-ink px-8 py-16 text-ivory sm:px-14 sm:py-20">
            <div className="absolute -right-24 -top-24 h-80 w-80 rounded-full bg-champagne/20 blur-3xl" />
            <div className="absolute -bottom-32 left-1/3 h-72 w-72 rounded-full bg-[#5B3A2A]/50 blur-3xl" />
            <div className="relative grid items-center gap-12 lg:grid-cols-[1.3fr_0.7fr]">
              <div>
                <p className="eyebrow text-champagne">Begin your signature</p>
                <h2 className="display mt-5 text-5xl text-ivory sm:text-6xl">
                  One sentence away
                  <br />
                  <em className="text-champagne">from your scent.</em>
                </h2>
                <p className="mt-6 max-w-md text-ivory/65">
                  “Warm, luxurious and mysterious for winter evenings.” That&apos;s all it takes to begin.
                </p>
                <div className="mt-10">
                  <Button href="/ai-perfume" variant="gold" size="lg" icon={<ArrowRight className="h-4 w-4" />}>
                    Create with AI
                  </Button>
                </div>
              </div>
              <div className="hidden justify-center lg:flex">
                <PerfumeBottle name="Solar Oud" color="#B5703A" size="lg" />
              </div>
            </div>
          </div>
        </Reveal>
      </section>
    </>
  );
}
