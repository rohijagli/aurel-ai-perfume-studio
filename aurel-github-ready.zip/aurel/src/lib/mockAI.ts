/**
 * ------------------------------------------------------------------
 *  AUREL mock AI layer
 * ------------------------------------------------------------------
 * Every function here returns a Promise that resolves to the exact JSON
 * shape (`ScentResult`) the real backend is expected to return.
 *
 * To connect a real AI service later, replace the body of each function
 * with a fetch to your API route, e.g.
 *
 *   const res = await fetch("/api/ai/generate", {
 *     method: "POST",
 *     headers: { "Content-Type": "application/json" },
 *     body: JSON.stringify({ prompt }),
 *   });
 *   return (await res.json()) as ScentResult;
 *
 * The UI only depends on these function signatures.
 * ------------------------------------------------------------------
 */
import type { ScentResult } from "./types";
import { hashString, sleep, uid } from "./utils";

/** Simulated network + model latency so the loading sequence can play. */
const MOCK_LATENCY_MS = 2800;

/* ----------------------------- Generate ----------------------------- */

interface Archetype {
  keywords: string[];
  result: Omit<ScentResult, "id" | "source" | "prompt">;
}

const GENERATION_ARCHETYPES: Archetype[] = [
  {
    // Primary demo result: "Warm, luxurious and mysterious for winter evenings"
    keywords: ["mysterious", "winter", "evening", "dark", "night", "smoky", "magnetic", "seductive", "leather", "noir"],
    result: {
      name: "Noir Éclat",
      family: "Woody Amber",
      category: "Amber",
      topNotes: ["Bergamot", "Pink Pepper"],
      heartNotes: ["Rose", "Black Tea"],
      baseNotes: ["Oud", "Amber", "Sandalwood"],
      description: "A warm, magnetic evening scent built around polished woods and a soft amber trail.",
      price: 7400,
      color: "#5B3A2A",
      profile: { freshness: 22, sweetness: 46, woody: 82, floral: 34, spicy: 58, musk: 52 },
      confidence: 91,
      mood: "Evening",
    },
  },
  {
    keywords: ["warm", "luxurious", "luxury", "cozy", "cosy", "vanilla", "sweet", "golden", "honey", "gourmand", "rich"],
    result: {
      name: "Ambre Doré",
      family: "Amber Gourmand",
      category: "Amber",
      topNotes: ["Saffron", "Pear"],
      heartNotes: ["Cardamom", "Jasmine"],
      baseNotes: ["Amber", "Vanilla", "Sandalwood"],
      description: "Liquid gold: glowing amber and spiced cardamom melting into a slow vanilla embrace.",
      price: 7200,
      color: "#C88A3E",
      profile: { freshness: 16, sweetness: 82, woody: 52, floral: 30, spicy: 56, musk: 46 },
      confidence: 89,
      mood: "Cozy",
    },
  },
  {
    keywords: ["romantic", "floral", "rose", "flower", "date", "love", "soft", "feminine", "petal", "bloom", "wedding"],
    result: {
      name: "Velvet Bloom",
      family: "Soft Floral",
      category: "Floral",
      topNotes: ["Pear", "Pink Pepper"],
      heartNotes: ["Rose", "Jasmine", "Iris"],
      baseNotes: ["Vanilla", "White Musk"],
      description: "Dewy rose petals and jasmine settle into a velvety vanilla skin musk.",
      price: 6900,
      color: "#D99AA5",
      profile: { freshness: 34, sweetness: 58, woody: 22, floral: 90, spicy: 20, musk: 56 },
      confidence: 93,
      mood: "Romantic",
    },
  },
  {
    keywords: ["fresh", "clean", "soap", "linen", "laundry", "morning", "office", "light", "airy", "crisp", "white"],
    result: {
      name: "White Hour",
      family: "Clean Musk",
      category: "Musk",
      topNotes: ["Pear", "Bergamot"],
      heartNotes: ["Iris", "Neroli"],
      baseNotes: ["White Musk", "Sandalwood"],
      description: "Freshly laundered linen and a soft musk halo. Quietly, unmistakably you.",
      price: 5400,
      color: "#E7DED2",
      profile: { freshness: 74, sweetness: 30, woody: 30, floral: 38, spicy: 8, musk: 86 },
      confidence: 88,
      mood: "Everyday",
    },
  },
  {
    keywords: ["beach", "beachy", "sea", "ocean", "summer", "refreshing", "vacation", "holiday", "salt", "aquatic", "citrus"],
    result: {
      name: "Salt Horizon",
      family: "Aquatic Citrus",
      category: "Fresh",
      topNotes: ["Yuzu", "Bergamot"],
      heartNotes: ["Neroli", "Sea Salt"],
      baseNotes: ["White Musk", "Cedar"],
      description: "Sea spray, sun-warmed skin and a twist of yuzu. A holiday you can wear.",
      price: 5800,
      color: "#7FB3C4",
      profile: { freshness: 92, sweetness: 22, woody: 26, floral: 24, spicy: 10, musk: 46 },
      confidence: 90,
      mood: "Summer",
    },
  },
];

/**
 * Generate a perfume from a free-text description.
 * Mock: keyword scoring against a handful of archetypes.
 * TODO(api): POST /api/ai/generate { prompt } -> ScentResult
 */
export async function generatePerfume(prompt: string): Promise<ScentResult> {
  await sleep(MOCK_LATENCY_MS);

  const text = prompt.toLowerCase();
  let best = 0;
  let bestScore = -1;
  GENERATION_ARCHETYPES.forEach((a, i) => {
    const score = a.keywords.reduce((s, k) => (text.includes(k) ? s + 1 : s), 0);
    if (score > bestScore) {
      best = i;
      bestScore = score;
    }
  });
  // No keywords matched: pick a stable archetype for this prompt.
  if (bestScore === 0) best = hashString(text) % GENERATION_ARCHETYPES.length;

  const archetype = GENERATION_ARCHETYPES[best].result;
  return {
    ...archetype,
    id: uid("ai"),
    source: "ai",
    prompt: prompt.trim(),
    // Slightly lower confidence when we had to guess.
    confidence: bestScore === 0 ? archetype.confidence - 7 : archetype.confidence,
  };
}

/* ------------------------------ Analyse ------------------------------ */

interface ReferenceProfile {
  match: string[];
  reference: string;
  result: Omit<ScentResult, "id" | "source" | "reference">;
}

const REFERENCE_LIBRARY: ReferenceProfile[] = [
  {
    match: ["bleu de chanel", "bleu", "chanel"],
    reference: "Bleu de Chanel",
    result: {
      name: "Bleu Rivage",
      family: "Woody Aromatic",
      category: "Woody",
      topNotes: ["Bergamot", "Pink Pepper"],
      heartNotes: ["Jasmine", "Cardamom"],
      baseNotes: ["Cedar", "Sandalwood"],
      accords: { top: "Citrus", heart: "Aromatic Spice", base: "Incense Woods" },
      description: "A crisp citrus opening drying down to smooth, incense-tinged woods. Polished and versatile.",
      price: 6900,
      color: "#3D5A80",
      profile: { freshness: 70, sweetness: 22, woody: 70, floral: 24, spicy: 42, musk: 40 },
      confidence: 91,
    },
  },
  {
    match: ["sauvage", "dior"],
    reference: "Dior Sauvage",
    result: {
      name: "Wild Meridian",
      family: "Aromatic Fougère",
      category: "Fresh",
      topNotes: ["Bergamot", "Pink Pepper"],
      heartNotes: ["Violet Leaf", "Cardamom"],
      baseNotes: ["Amber", "Cedar"],
      accords: { top: "Peppery Citrus", heart: "Lavender Spice", base: "Ambery Woods" },
      description: "Electric bergamot and pepper over a mineral, ambery base. Raw and magnetic.",
      price: 6400,
      color: "#4A6B8A",
      profile: { freshness: 78, sweetness: 24, woody: 58, floral: 18, spicy: 56, musk: 44 },
      confidence: 90,
    },
  },
  {
    match: ["baccarat", "rouge 540", "540", "kurkdjian"],
    reference: "Baccarat Rouge 540",
    result: {
      name: "Crystal Ember",
      family: "Amber Floral",
      category: "Amber",
      topNotes: ["Saffron"],
      heartNotes: ["Jasmine"],
      baseNotes: ["Amber", "Cedar"],
      accords: { top: "Saffron", heart: "Airy Floral", base: "Amberwood" },
      description: "A luminous ambery-woody glow with a sugared saffron edge. Radiant and addictive.",
      price: 8200,
      color: "#C4473A",
      profile: { freshness: 24, sweetness: 70, woody: 58, floral: 46, spicy: 40, musk: 50 },
      confidence: 93,
    },
  },
  {
    match: ["aventus", "creed"],
    reference: "Creed Aventus",
    result: {
      name: "Laurel Crown",
      family: "Fruity Chypre",
      category: "Woody",
      topNotes: ["Pear", "Bergamot"],
      heartNotes: ["Jasmine", "Rose"],
      baseNotes: ["White Musk", "Oud"],
      accords: { top: "Fruity", heart: "Smoky Floral", base: "Mossy Musk" },
      description: "Juicy orchard fruit, a whisper of smoke and a confident mossy musk.",
      price: 8600,
      color: "#6B7B5A",
      profile: { freshness: 60, sweetness: 46, woody: 64, floral: 30, spicy: 28, musk: 58 },
      confidence: 89,
    },
  },
  {
    match: ["black opium", "opium", "ysl"],
    reference: "Black Opium",
    result: {
      name: "Café Nocturne",
      family: "Amber Gourmand",
      category: "Amber",
      topNotes: ["Pink Pepper", "Pear"],
      heartNotes: ["Jasmine", "Neroli"],
      baseNotes: ["Vanilla", "Cedar"],
      accords: { top: "Pear Spice", heart: "Coffee Floral", base: "Vanilla" },
      description: "Black coffee and white florals over a deep vanilla — after-midnight energy.",
      price: 7100,
      color: "#3B2A2E",
      profile: { freshness: 18, sweetness: 84, woody: 40, floral: 52, spicy: 34, musk: 42 },
      confidence: 90,
    },
  },
];

/** Generic interpretations used when a reference isn't in the mock library. */
const FALLBACK_INTERPRETATIONS: ReferenceProfile["result"][] = [
  {
    name: "Velours Boisé",
    family: "Woody",
    category: "Woody",
    topNotes: ["Bergamot", "Saffron"],
    heartNotes: ["Cardamom", "Iris"],
    baseNotes: ["Sandalwood", "Cedar"],
    accords: { top: "Citrus", heart: "Spice", base: "Soft Woods" },
    description: "A refined woody interpretation with a bright opening and a velvety finish.",
    price: 6800,
    color: "#8A6446",
    profile: { freshness: 42, sweetness: 30, woody: 76, floral: 28, spicy: 46, musk: 42 },
    confidence: 86,
  },
  {
    name: "Fleur Mémoire",
    family: "Floral",
    category: "Floral",
    topNotes: ["Pear", "Bergamot"],
    heartNotes: ["Rose", "Jasmine"],
    baseNotes: ["White Musk", "Vanilla"],
    accords: { top: "Fruity", heart: "White Floral", base: "Soft Musk" },
    description: "A luminous floral echo of your reference, softened with clean musk.",
    price: 6600,
    color: "#D8A3AE",
    profile: { freshness: 40, sweetness: 54, woody: 22, floral: 82, spicy: 14, musk: 58 },
    confidence: 84,
  },
  {
    name: "Clair Sillage",
    family: "Fresh",
    category: "Fresh",
    topNotes: ["Yuzu", "Basil"],
    heartNotes: ["Neroli", "Violet Leaf"],
    baseNotes: ["Cedar", "White Musk"],
    accords: { top: "Citrus", heart: "Green", base: "Clean Woods" },
    description: "A crisp, airy reading of your reference with green citrus and clean woods.",
    price: 5900,
    color: "#93BDB2",
    profile: { freshness: 84, sweetness: 18, woody: 40, floral: 30, spicy: 12, musk: 44 },
    confidence: 85,
  },
];

function titleCase(value: string): string {
  return value
    .trim()
    .split(/\s+/)
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
    .join(" ");
}

/**
 * Analyse a perfume by name and propose an AUREL interpretation.
 * TODO(api): POST /api/ai/analyze { name } -> ScentResult
 */
export async function analyzePerfume(name: string): Promise<ScentResult> {
  await sleep(MOCK_LATENCY_MS);

  const query = name.toLowerCase().trim();
  const known = REFERENCE_LIBRARY.find((r) => r.match.some((m) => query.includes(m)));

  if (known) {
    return { ...known.result, id: uid("clone"), source: "clone", reference: known.reference };
  }

  const fallback = FALLBACK_INTERPRETATIONS[hashString(query) % FALLBACK_INTERPRETATIONS.length];
  return { ...fallback, id: uid("clone"), source: "clone", reference: titleCase(name) };
}

/**
 * "Recognise" a perfume from an uploaded image.
 * Mock: no computer vision — always returns the Luxury Oud analysis.
 * TODO(api): POST /api/ai/clone-image (multipart/form-data) -> ScentResult
 */
export async function clonePerfume(image: File | null): Promise<ScentResult> {
  // `image` would be uploaded to the vision model here.
  void image;
  await sleep(MOCK_LATENCY_MS);

  return {
    id: uid("clone"),
    source: "clone",
    reference: "Luxury Oud Perfume",
    name: "Oud Mirage",
    family: "Woody",
    category: "Woody",
    topNotes: ["Bergamot", "Yuzu"],
    heartNotes: ["Cardamom", "Saffron"],
    baseNotes: ["Cedar", "Oud"],
    accords: { top: "Citrus", heart: "Spice", base: "Cedar / Oud" },
    description: "A desert-dry oud lifted by citrus and warm spice, finishing on resinous cedar.",
    price: 8400,
    color: "#6E4A2F",
    profile: { freshness: 34, sweetness: 28, woody: 88, floral: 16, spicy: 62, musk: 40 },
    confidence: 91,
  };
}

/** Loading copy for the generator and clone flows. */
export const GENERATE_STEPS = [
  "Analyzing your mood…",
  "Building fragrance profile…",
  "Balancing notes…",
  "Your scent is ready.",
];

export const CLONE_STEPS = [
  "Reading the reference…",
  "Identifying the fragrance family…",
  "Mapping top, heart and base…",
  "Analysis complete.",
];
