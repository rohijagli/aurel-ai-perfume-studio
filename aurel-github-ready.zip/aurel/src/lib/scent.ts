import type { ScentDimension, ScentProfile } from "./types";

export interface DimensionMeta {
  key: ScentDimension;
  label: string;
  /** Colour this dimension tints the juice with. */
  color: string;
  low: string;
  high: string;
}

export const DIMENSIONS: DimensionMeta[] = [
  { key: "freshness", label: "Freshness", color: "#8DBFB6", low: "Soft", high: "Crisp" },
  { key: "sweetness", label: "Sweetness", color: "#E2B37E", low: "Dry", high: "Gourmand" },
  { key: "woody", label: "Woody", color: "#7E5D3F", low: "Light", high: "Deep" },
  { key: "floral", label: "Floral", color: "#D79AA8", low: "Subtle", high: "Bouquet" },
  { key: "spicy", label: "Spicy", color: "#B9653A", low: "Gentle", high: "Fiery" },
  { key: "musk", label: "Musk", color: "#BFB2A3", low: "Sheer", high: "Skin-close" },
];

export const DEFAULT_PROFILE: ScentProfile = {
  freshness: 40,
  sweetness: 40,
  woody: 50,
  floral: 40,
  spicy: 30,
  musk: 40,
};

function hexToRgb(hex: string): [number, number, number] {
  const clean = hex.replace("#", "");
  const full = clean.length === 3 ? clean.split("").map((c) => c + c).join("") : clean;
  const n = parseInt(full, 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

function rgbToHex([r, g, b]: [number, number, number]): string {
  return "#" + [r, g, b].map((v) => Math.round(Math.max(0, Math.min(255, v))).toString(16).padStart(2, "0")).join("");
}

export function hexToRgba(hex: string, alpha: number): string {
  const [r, g, b] = hexToRgb(hex);
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}

export function mixHex(a: string, b: string, weightOfB: number): string {
  const ca = hexToRgb(a);
  const cb = hexToRgb(b);
  return rgbToHex([0, 1, 2].map((i) => ca[i] * (1 - weightOfB) + cb[i] * weightOfB) as [number, number, number]);
}

/**
 * Blend the dimension colours by intensity to produce the juice colour shown
 * in the bottle. Stronger dimensions dominate (weights are squared).
 */
export function profileToColor(profile: ScentProfile, base?: string): string {
  let total = 0;
  const acc: [number, number, number] = [0, 0, 0];
  for (const d of DIMENSIONS) {
    const w = Math.pow(profile[d.key] / 100, 2) + 0.001;
    const [r, g, b] = hexToRgb(d.color);
    acc[0] += r * w;
    acc[1] += g * w;
    acc[2] += b * w;
    total += w;
  }
  const blended = rgbToHex([acc[0] / total, acc[1] / total, acc[2] / total]);
  return base ? mixHex(blended, base, 0.35) : blended;
}

/** The two strongest dimensions, e.g. "Woody · Spicy". */
export function dominantLabel(profile: ScentProfile): string {
  return [...DIMENSIONS]
    .sort((a, b) => profile[b.key] - profile[a.key])
    .slice(0, 2)
    .map((d) => d.label)
    .join(" · ");
}

/** Overall projection descriptor from average intensity. */
export function intensityLabel(profile: ScentProfile): string {
  const values = Object.values(profile);
  const avg = values.reduce((s, v) => s + v, 0) / values.length;
  if (avg < 30) return "Whisper-soft, intimate";
  if (avg < 48) return "Balanced, everyday";
  if (avg < 64) return "Confident, noticeable";
  return "Bold, room-filling";
}
