/**
 * Shared domain types for AUREL.
 * These mirror the JSON shape a future AI / catalogue API is expected to return,
 * so swapping mock data for real endpoints should not require UI changes.
 */

export type FragranceCategory = "Fresh" | "Floral" | "Woody" | "Amber" | "Citrus" | "Musk";

export type NoteTier = "top" | "heart" | "base";

export type ScentDimension = "freshness" | "sweetness" | "woody" | "floral" | "spicy" | "musk";

/** 0–100 intensity for each scent dimension. */
export type ScentProfile = Record<ScentDimension, number>;

export interface Perfume {
  id: string;
  name: string;
  /** Display family, e.g. "Woody Amber". */
  family: string;
  /** Filter category used on Explore. */
  category: FragranceCategory;
  topNotes: string[];
  heartNotes: string[];
  baseNotes: string[];
  description: string;
  /** Price in INR for a 50 ml Eau de Parfum. */
  price: number;
  /** Hex colour of the juice, used by <PerfumeBottle />. */
  color: string;
  profile: ScentProfile;
  mood?: string;
}

export type CreationSource = "ai" | "clone" | "custom" | "catalog";

/** What the (mock) AI returns for generate / analyse / clone requests. */
export interface ScentResult extends Perfume {
  /** AI confidence (generate) or similarity to reference (clone), 0–100. */
  confidence: number;
  source: CreationSource;
  /** For clones: the perfume or image the user started from. */
  reference?: string;
  /** For clones: high-level accord summary per tier. */
  accords?: { top: string; heart: string; base: string };
  /** For AI generations: the prompt that produced it. */
  prompt?: string;
}

/** A fragrance saved into the user's collection. */
export interface Creation extends ScentResult {
  createdAt: string; // ISO date
}
