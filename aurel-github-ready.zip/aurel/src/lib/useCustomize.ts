"use client";

import { useCallback } from "react";
import { useRouter } from "next/navigation";
import { useStudio } from "@/context/StudioContext";
import type { Perfume, ScentResult } from "./types";

/** Returns a handler that loads a fragrance into the studio and opens /customize. */
export function useCustomize() {
  const router = useRouter();
  const { setDraft, draftFromPerfume } = useStudio();

  return useCallback(
    (item: Perfume | ScentResult) => {
      const draft = "source" in item ? (item as ScentResult) : draftFromPerfume(item);
      setDraft(draft);
      router.push("/customize");
    },
    [router, setDraft, draftFromPerfume],
  );
}
