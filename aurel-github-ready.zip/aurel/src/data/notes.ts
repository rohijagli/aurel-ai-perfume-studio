import type { NoteTier } from "@/lib/types";

export interface NoteOption {
  name: string;
  tier: NoteTier;
  /** Short sensory descriptor shown on hover / under the chip. */
  hint: string;
}

/** Note library for the Customize page. Future: GET /api/notes */
export const NOTE_LIBRARY: Record<NoteTier, NoteOption[]> = {
  top: [
    { name: "Bergamot", tier: "top", hint: "Bright citrus" },
    { name: "Yuzu", tier: "top", hint: "Zesty, sparkling" },
    { name: "Pear", tier: "top", hint: "Juicy, crisp" },
    { name: "Saffron", tier: "top", hint: "Leathery spice" },
    { name: "Basil", tier: "top", hint: "Green, herbal" },
    { name: "Pink Pepper", tier: "top", hint: "Rosy spice" },
  ],
  heart: [
    { name: "Rose", tier: "heart", hint: "Velvet petals" },
    { name: "Neroli", tier: "heart", hint: "Orange blossom" },
    { name: "Iris", tier: "heart", hint: "Powdery, cool" },
    { name: "Jasmine", tier: "heart", hint: "Heady, sensual" },
    { name: "Violet Leaf", tier: "heart", hint: "Green, dewy" },
    { name: "Cardamom", tier: "heart", hint: "Warm, aromatic" },
  ],
  base: [
    { name: "Oud", tier: "base", hint: "Smoky, resinous" },
    { name: "Sandalwood", tier: "base", hint: "Creamy wood" },
    { name: "Vanilla", tier: "base", hint: "Soft, sweet" },
    { name: "Amber", tier: "base", hint: "Golden warmth" },
    { name: "White Musk", tier: "base", hint: "Clean skin" },
    { name: "Cedar", tier: "base", hint: "Dry, pencil wood" },
  ],
};

export const TIER_LABELS: Record<NoteTier, string> = {
  top: "Top Notes",
  heart: "Heart Notes",
  base: "Base Notes",
};

export const TIER_DESCRIPTIONS: Record<NoteTier, string> = {
  top: "First impression · 15 min",
  heart: "The character · 2–4 hrs",
  base: "The lasting trail · 6+ hrs",
};

export const MAX_SELECTED_NOTES = 6;

const ALL_NOTE_NAMES = new Set(
  Object.values(NOTE_LIBRARY).flatMap((tier) => tier.map((n) => n.name)),
);

export function isLibraryNote(name: string): boolean {
  return ALL_NOTE_NAMES.has(name);
}

export function tierOf(name: string): NoteTier | undefined {
  for (const tier of ["top", "heart", "base"] as NoteTier[]) {
    if (NOTE_LIBRARY[tier].some((n) => n.name === name)) return tier;
  }
  return undefined;
}
